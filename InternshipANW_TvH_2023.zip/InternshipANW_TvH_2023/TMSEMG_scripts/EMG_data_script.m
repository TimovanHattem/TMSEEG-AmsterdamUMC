%% EMG (MEP) ANALYSIS
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: converted EMG file (*.set) !YOU NEED THE ConversionPoly5Set.m SCRIPT FOR THIS IN THE TMSi-_MATLAB_Interface FOLDER!
% OUTPUT: MEPs

%% Clean workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEMG_scripts/') %path to personal scratch folder, change accordingly to user
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEMG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEMG_scripts/'));
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0');
fprintf('Paths added!\n')

eeglab;

%% MEPs

ppns = {'TC913','TC915','TC919','TC920','TC921'}; %INPUT REQUIRED
samp = 1024;

for ppn=1:size(ppns,2)
    
    EEG = pop_loadset('filename', [ppns{ppn}, '_EMG.set'], 'filepath', ['/scratch/anw/tvanhattem/analysis_tvh/TMSEMG_data/EMG_converted/']);
    EMG = EEG;

    DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/raw_epochs/', ppns{ppn}, '/M1/'];
    EEG_SP = pop_loadset('filename', [ppns{ppn}, '_rawepochs_M1_SP.set'], 'filepath', [DATAIN]);
    EEG_D2 = pop_loadset('filename', [ppns{ppn}, '_rawepochs_M1_D2.set'], 'filepath', [DATAIN]);
    EEG_D10 = pop_loadset('filename', [ppns{ppn}, '_rawepochs_M1_D10.set'], 'filepath', [DATAIN]);

    ev_idx_SP = [EEG_SP.event.urevent];
    ev_idx_D2 = [EEG_D2.event.urevent];
    ev_idx_D10 = [EEG_D10.event.urevent];

    EMG = pop_chanevent(EMG, 3,'edge','leading','delchan','off','delevent','off');

    EMG = pop_select(EMG, 'channel', {'B'});

    %EMG = pop_resample(EMG, samp);

    EMG = pop_eegfiltnew(EMG, 1, [], [], 0);
    EMG = pop_eegfiltnew(EMG, 48, 52, [], 1); %notch filter 48-52

%     for i = 1:size(EMG.urevent, 2)
%         if ismember(i, ev_idx_D2)
%             EMG.urevent(i).latency = EMG.urevent(i).latency + (0.002*samp);
%             EMG.event(i).latency = EMG.event(i).latency + (0.002*samp);
%         elseif ismember(i, ev_idx_D10)
%             EMG.urevent(i).latency = EMG.urevent(i).latency + (0.010*samp);
%             EMG.event(i).latency = EMG.event(i).latency + (0.010*samp);
%         end
%     end

    EMG = pop_epoch(EMG, {'chan3'}, [-0.01 0.1]);

    EMG = pop_rmbase(EMG, []);
   
    data_emg_sp = mean(EMG.data(:,:,ev_idx_SP),3);
    data_emg_D2 = mean(EMG.data(:,:,ev_idx_D2),3);
    data_emg_D10 = mean(EMG.data(:,:,ev_idx_D10),3);

%     [emg_mep(ppn).SP_pos, a] = max(data_emg_sp(30:51));
%     [emg_mep(ppn).SP_neg, b] = min(data_emg_sp(30:51));
%     emg_mep(ppn).SP_peaktopeak = abs(emg_mep(ppn).SP_pos)+abs(emg_mep(ppn).SP_neg);
%     [emg_mep(ppn).D2_pos, c] = max(data_emg_D2(30:51));
%     [emg_mep(ppn).D2_neg, d] = min(data_emg_D2(30:51));
%     emg_mep(ppn).D2_peaktopeak = abs(emg_mep(ppn).D2_pos)+abs(emg_mep(ppn).D2_neg);
%     [emg_mep(ppn).D10_pos, e] = max(data_emg_D10(30:51));
%     [emg_mep(ppn).D10_neg, f] = min(data_emg_D10(30:51));
%     emg_mep(ppn).D10_peaktopeak = abs(emg_mep(ppn).D10_pos)+abs(emg_mep(ppn).D10_neg);
    
%     x  = 1:112;
%     figure
%     plot(x,data_emg_sp, 'b', 'LineWidth', 1.15)
%     hold on
%     plot(x,data_emg_D2, 'r','LineWidth', 1.15)
%     hold on
%     plot(x,data_emg_D10, 'g','LineWidth', 1.15)
%     line([30 30], [-100 100], 'Color', 'black', 'LineStyle', '--')
%     line([51 51], [-100 100], 'Color', 'black', 'LineStyle', '--')
%     
%     x  = 1:112;
%     figure
%     plot(x,data_emg_sp, 'b', 'LineWidth', 1.15)
%     line([a+29 a+29], [-100 100], 'Color', 'black', 'LineStyle', '--')
%     line([b+29 b+29], [-100 100], 'Color', 'black', 'LineStyle', '--')
%     figure
%     plot(x,data_emg_D2, 'r','LineWidth', 1.15)
%     line([c+29 c+29], [-50 50], 'Color', 'black', 'LineStyle', '--')
%     line([d+29 d+29], [-50 50], 'Color', 'black', 'LineStyle', '--')
%     figure
%     plot(x,data_emg_D10, 'g','LineWidth', 1.15)
%     line([e+29 e+29], [-100 100], 'Color', 'black', 'LineStyle', '--')
%     line([f+29 f+29], [-100 100], 'Color', 'black', 'LineStyle', '--')
    
    emg_sp_all(ppn,:) = data_emg_sp;
    emg_D2_all(ppn,:) = data_emg_D2;
    emg_D10_all(ppn,:) = data_emg_D10;

end

%% GRAND-AVERAGE MEPs + BOXPLOTS
emg_sp_all_mean = mean(emg_sp_all,1);
emg_D2_all_mean = mean(emg_D2_all,1);
emg_D10_all_mean = mean(emg_D10_all,1);

x = 1:112;

figure
plot(x,emg_sp_all_mean, 'b', 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,emg_D2_all_mean, 'r','Color', [0.8500 0.3250 0.0980],'LineWidth', 3.5)
hold on
plot(x,emg_D10_all_mean, 'g','Color', [0.9290 0.6940 0.1250],'LineWidth', 3.5)
stdshade(emg_sp_all, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(emg_D2_all, 0.12,[0.8500 0.3250 0.0980],x,[]);
stdshade(emg_D10_all, 0.12,[0.9290 0.6940 0.1250],x,[]);
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
xlabel('Time (ms)')
ylabel('Amplitude (mV)')
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

% box_emg(1,:) = [emg_mep.SP_peaktopeak];
% box_emg(2,:) = [emg_mep.D2_peaktopeak];
% box_emg(3,:) = [emg_mep.D10_peaktopeak];
% figure
% x = categorical({'SP','SICI','ICF'});
% boxplot(box_emg',x)
% set(gcf, 'Position', get(0, 'Screensize'));
% set(gca,'box','off')
% set(gca, 'LineWidth',2.5)
% xlabel('Stimulation condition')
% ylabel('Amplitude (mV)')     