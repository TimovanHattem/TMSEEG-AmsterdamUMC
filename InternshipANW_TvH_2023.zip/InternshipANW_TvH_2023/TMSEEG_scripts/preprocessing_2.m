%% PREPROCESSING TMS-EEG, 2/2
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: raw epochs (*.set)
% OUTPUT: clean epochs (*.set)

%% Clean workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/') %path to personal scratch folder, change accordingly to user
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0')
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

%% Initialize variables
ppn = 'TC922'; %INPUT REQUIRED: subject number
br = 'lDLPFC'; %INPUT REQUIRED: brain region of interest
con = 'SP'; %INPUT REQUIRED: stimulation condition

%set input and output paths
DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/raw_epochs/', ppn, '/', br, '/'];
DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/'];

%% Import data
eeglab;
EEG = pop_loadset('filename', [ppn, '_rawepochs_', br, '_', con, '.set'], 'filepath', [DATAIN]); %load raw epochs (*.set)

%% Remove TMS artefact around test pulse, interval depending on stimulation condition, add constant amplitude
if strcmpi(con, 'SP')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]); %includes TMS artefact of conditioning pulse
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]); %includes TMS artefact of conditioning pulse
end

%% Interpolate removed data prior to downsampling
EEG = pop_tesa_interpdata(EEG, 'cubic', [1 1]);

%% Downsample 10KHz to 1KHz
EEG = pop_resample(EEG, 1000);

%% Automated removal bad epochs
EEG = pop_jointprob(EEG,1,[1:size(EEG,1)],3,3,0,1,0,[],0); %based on joint probability
EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent])); %save original information / changes in final dataset

%% Manual trial rejection 1/2

% trial rejection, mark bad trials
pop_eegplot(EEG,1,1,1) %scroll through data, inspect each epoch separately
EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent])); %save original information / changes in final dataset

% if present, remove bad channel
EEG = pop_select(EEG, 'nochannel', {'TP9','TP10'}); %INPUT REQUIRED: bad channels detected using pop_eegplot()
EEG.rejchan = find(~ismember([EEG.allchan.urchan], [EEG.chanlocs.urchan])); %save original information / changes in final dataset

%% Remove data around test pulse, interval depending on stimulation condition, add constant amplitude
if strcmpi(con, 'SP')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]); %includes TMS artefact of conditioning pulse
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]); %includes TMS artefact of conditioning pulse
end

%% ICA round 1, remove only TMS artefacts and TMS-induced muscle activity
EEG = pop_tesa_fastica(EEG, 'approach', 'symm', 'g', 'tanh', 'stabilization', 'on');
EEG = pop_tesa_compselect(EEG,'compCheck','on','remove','on','saveWeights','off', 'figSize','medium','plotTimeX',[-200 500],'plotFreqX',[1 100],'freqScale', 'log', 'tmsMuscle','on','tmsMuscleThresh',8,'tmsMuscleWin',[15 30],'tmsMuscleFeedback','off','blink','off','blinkThresh',2.5,'blinkElecs',{'Fp1','Fp2'},'blinkFeedback','off','move','off','moveThresh',2,'moveElecs',{'F7','F8'},'moveFeedback','off','muscle','off','muscleThresh',-0.31,'muscleFreqIn',[7 70],'muscleFreqEx',[48 52],'muscleFeedback','off','elecNoise','off','elecNoiseThresh',4,'elecNoiseFeedback','off' );

%% Interpolate remove data prior to filtering
EEG = pop_tesa_interpdata(EEG, 'cubic', [10 10]);

%% Filtering
EEG = pop_tesa_filtbutter(EEG, 1, 80, 4, 'bandpass'); %bandpass filter 1-80 Hz)
EEG = pop_tesa_filtbutter(EEG, 48, 52, 4, 'bandstop' ); %notch filter 48-52 Hz)

%% SOUND (not included, but potential additional cleaning method)
%EEG = pop_tesa_sound(EEG, 'lambdaValue', 0.1, 'iter', 5);

%% Manual trial rejection 2/2
pop_eegplot(EEG,1,1,1)
EEG = pop_select(EEG, 'notrial', [6,14]); %INPUT REQUIRED: rejected trials
EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent])); %save original information / changes in final dataset

%% Remove data around test pulse, interval depending on stimulation condition, add constant amplitude
if strcmpi(con, 'SP')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]); %includes TMS artefact of conditioning pulse
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]); %includes TMS artefact of conditioning pulse
end

%% ICA round 2, remove all residual artefacts (e.g. eyeblinks, electrode noise, etc.)
EEG = pop_tesa_fastica(EEG, 'approach', 'symm', 'g', 'tanh', 'stabilization', 'on');
EEG = pop_tesa_compselect(EEG,'compCheck','on','remove','on','saveWeights','off', 'figSize','medium','plotTimeX',[-200 500],'plotFreqX',[1 100],'freqScale', 'log', 'tmsMuscle','on','tmsMuscleThresh',8,'tmsMuscleWin',[15 30],'tmsMuscleFeedback','off','blink','on','blinkThresh',2.5,'blinkElecs',{'AF7','AF8'},'blinkFeedback','off','move','on','moveThresh',2,'moveElecs',{'F7','F8'},'moveFeedback','off','muscle','on','muscleThresh',-0.31,'muscleFreqIn',[7 70],'muscleFreqEx',[48 52],'muscleFeedback','off','elecNoise','on','elecNoiseThresh',4,'elecNoiseFeedback','off' );

%% Interpolate removed data around TMS-pulse
EEG = pop_tesa_interpdata(EEG, 'cubic', [10 10]);

%% Interpolate removed channels using spherical interpolation
EEG = pop_interp(EEG, EEG.allchan, 'spherical');

%% Rereference data to average of all electrodes
EEG = pop_reref(EEG, []);
%pop_eegplot(EEG,1,1,1)

%% Save dataset
mkdir([DATAOUT, '/', ppn, '/', br])
pop_saveset(EEG, 'filename', [ppn, '_preprocessed_', br, '_', con, '.set'], 'filepath', [DATAOUT, '/', ppn, '/' br]);

