%% PREPROCESSING TMS-EEG, 1/2
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: Curry8 files of raw EEG recordings (*.cdt)
% OUTPUT: raw epochs (*.set)

%% Clear workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/') %path to personal scratch folder, change accordingly to user
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0'); 
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

%% Initialize variables
ppn = 'TC922'; %INPUT REQUIRED: subject number
br = 'lDLPFC'; %INPUT REQUIRED: region of interest

% set input and output paths
DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/raw/', ppn, '/', br, '/'];
%DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/convert/', ppn, '/', br, '/'];
DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/raw_epochs/'];

%% Import data
eeglab;
EEG = loadcurry([DATAIN, dir(fullfile(DATAIN, '*.cdt')).name], 'KeepTriggerChannel', 'False', 'CurryLocations', 'False'); %load raw file (*.cdt)
%EEG = pop_biosig(); %load converted file (*.set)

%% Load channel locations
EEG = pop_chanedit(EEG,'lookup','/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/plugins/dipfit/standard_BEM/elec/standard_1020.elc');

%% Remove unused electrodes
EEG = pop_select(EEG, 'nochannel', [63:68]); %remove channel 31, 32, VEOG, HEOG, EKG, EMG
EEG.allchan = EEG.chanlocs; %save original information / changes in final dataset

%% Automated removal bad electrodes step 1
EEG = pop_clean_rawdata(EEG, 'FlatlineCriterion',5,'Highpass', 'off','ChannelCriterion',0.8,'LineNoiseCriterion',4,'BurstCriterion','off','WindowCriterion','off');
EEG.rejchan = find(~ismember([EEG.allchan.urchan], [EEG.chanlocs.urchan])); %save original information / changes in final dataset

%% Automated removal bad electrodes step 2
EEG = pop_rejchan(EEG, 'elec', [1:size(EEG.data,1)], 'threshold', 4, 'norm', 'on', 'measure', 'kurt'); %based on kurtosis
EEG.rejchan = find(~ismember([EEG.allchan.urchan], [EEG.chanlocs.urchan])); %save original information / changes in final dataset

%% Fix latency of events in D2 and D10 condition (from marker on conditioning pulse to marker on test pulse)
EEG.oldeventlatency = [EEG.event.latency]; %save original information / changes in final dataset
for i = 1:size(EEG.event,2)
    if EEG.event(i).type == 3
        EEG.event(i).latency = EEG.event(i).latency + 21;
        EEG.urevent(i).latency = EEG.urevent(i).latency + 21;
    elseif EEG.event(i).type == 5
        EEG.event(i).latency = EEG.event(i).latency + 101;
        EEG.urevent(i).latency = EEG.urevent(i).latency + 101;
    end
end

%% Epoch segmentation
EEG = pop_epoch(EEG, {'1', '3', '5'}, [-1.5 1.5]);

%% Baseline correction
EEG = pop_rmbase(EEG, [-800 -110]);
%pop_eegplot(EEG,1,1,1);

%% Seperate epochs on condition
EEG_SP = pop_select(EEG, 'trial', find(([EEG.event.type] == 1))); %SP
EEG_D2 = pop_select(EEG, 'trial', find(([EEG.event.type] == 3))); %D2
EEG_D10 = pop_select(EEG, 'trial', find(([EEG.event.type] == 5))); %D10

%% Save additional information for later checks
EEG_SP.rawepochs = EEG_SP.epoch;
EEG_SP.rawurevents = EEG_SP.urevent;
EEG_D2.rawepochs = EEG_D2.epoch;
EEG_D2.rawurevents = EEG_D2.urevent;
EEG_D10.rawepochs = EEG_D10.epoch;
EEG_D10.rawurevents = EEG_D10.urevent;

%% Manually check for true presence of TMS-pulse at given marker SP
EEG_pulsecheck_SP = epoch2continuous(EEG_SP);
EEG_pulsecheck_SP = tesa_findpulse(EEG_pulsecheck_SP, ['CZ'], 'refract', 5, 'rate', 1e4, 'tmsLabel', 'SP'); %change target channel if needed
EEG_SP.pulseinfo = EEG_pulsecheck_SP.event;
% pop_eegplot(EEG_pulsecheck_SP,1,1,1); %check true presence of TMS artefact (i.e. large peaks with constant intervals of 4-6 seconds)
% EEG_SP = pop_select(EEG_SP, 'notrial', [44:51]) %if missing visible TMS artefact at given markers, delete epochs in question

%% Manually check for true presence of TMS-pulse at given marker D2
EEG_pulsecheck_D2 = epoch2continuous(EEG_D2);
EEG_pulsecheck_D2 = tesa_findpulse(EEG_pulsecheck_D2, 'CZ', 'refract', 2, 'rate', 2e4, 'paired', 'yes', 'ISI', [2]); %change target channel if needed
EEG_D2.pulseinfo = EEG_pulsecheck_D2.event;
% pop_eegplot(EEG_pulsecheck_D2,1,1,1); %check true presence of TMS artefact (i.e. large peaks with constant intervals of 4-6 seconds)
% EEG_D2 = pop_select(EEG_D2, 'notrial', [45:51]) %if missing visible TMS artefact at given markers, delete epochs in question

%% Manually check for true presence of TMS-pulse at given marker D10
EEG_pulsecheck_D10 = epoch2continuous(EEG_D10);
EEG_pulsecheck_D10 = tesa_findpulse(EEG_pulsecheck_D10, 'CZ', 'refract', 10, 'rate', 1e4, 'paired', 'yes', 'ISI', [10]); %change target channel if needed
EEG_D10.pulseinfo = EEG_pulsecheck_D10.event;
% pop_eegplot(EEG_pulsecheck_D10,1,1,1); %check true presence of TMS artefact (i.e. large peaks with constant intervals of 4-6 seconds)
% EEG_D10 = pop_select(EEG_D10, 'notrial', [45:51]) %if missing visible TMS artefact at given markers, delete epochs in question

%% Seperate epochs for conditions and save
mkdir([DATAOUT, '/', ppn, '/', br])
pop_saveset(EEG_SP, 'filename', [ppn, '_rawepochs_', br, '_SP.set'], 'filepath', [DATAOUT, ppn, '/', br]);
pop_saveset(EEG_D2, 'filename', [ppn, '_rawepochs_', br, '_D2.set'], 'filepath', [DATAOUT, ppn, '/', br]);
pop_saveset(EEG_D10, 'filename', [ppn, '_rawepochs_', br, '_D10.set'], 'filepath', [DATAOUT, ppn, '/', br]);