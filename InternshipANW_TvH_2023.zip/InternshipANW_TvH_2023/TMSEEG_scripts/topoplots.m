%% TOPOPLOTS
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: clean epochs (*.set)
% OUTPUT: topoplots

%% Clean workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/') %path to personal scratch folder, change accordingly to user
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/'));
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0');
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/'));
fprintf('Paths added!\n')

eeglab;
%% LOOP TOPOPLOTS INDIVIDUAL LEVEL

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'}; %INPUT REQUIRED
%ppns = {'TC910', 'TC913'};
brs = {'lDLPFC', 'rDLPFC'}; %INPUT REQUIRED
%brs = {'lDLPFC'};
cons = {'SP', 'D2','D10'}; %INPUT REQUIRED
%cons = {'SP'};

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/topoplots/'];
eeglab;

tw_n40 = [0.03 0.05]; %define time window
tw_p60 = [0.055 0.075]; %define time window
tw_n100 = [0.09 0.14]; %define time window
tw_p185 = [0.16 0.24]; %define time window

% find peaks time windows
s_rate = 1000; % in Hz
pre_base = 1.5; % in seconds

indx_n40 = (tw_n40 * s_rate) + (pre_base * s_rate); %find indices
indx_p60 = (tw_p60 * s_rate) + (pre_base * s_rate); %find indices
indx_n100 = (tw_n100 * s_rate) + (pre_base * s_rate); %find indices
indx_p185 = (tw_p185 * s_rate) + (pre_base * s_rate); %find indices

for ppn=1:size(ppns,2)
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            % find data
            data_n40 = mean(mean(EEG.data(:, indx_n40(1):indx_n40(2), :),2),3);
            data_p60 = mean(mean(EEG.data(:, indx_p60(1):indx_p60(2), :),2),3);
            data_n100 = mean(mean(EEG.data(:, indx_n100(1):indx_n100(2), :),2),3);
            data_p185 = mean(mean(EEG.data(:, indx_p185(1):indx_p185(2), :),2),3);

            % make topoplots
            figure;
            subplot(2,2,1);
            topoplot_tvh(data_n40, EEG.chanlocs, 'headrad', 0.64);
            title('N40');
            subplot(2,2,2);
            topoplot_tvh(data_p60, EEG.chanlocs,'headrad', 0.64 );
            title('P60');
            subplot(2,2,3);
            topoplot_tvh(data_n100, EEG.chanlocs, 'headrad', 0.64);
            title('N100');
            subplot(2,2,4);
            topoplot_tvh(data_p185, EEG.chanlocs, 'headrad', 0.64);
            title('P185');
            %saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_Topoplots.jpg']);

            close
        end
    end
end

%% GRAND-AVERAGE TOPOPLOTS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_grand.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/topoplots/EEG_chanlocs.mat'])

tw_n40 = [0.03 0.05]; %define time window
tw_p60 = [0.055 0.075]; %define time window
tw_n100 = [0.09 0.14]; %define time window
tw_p185 = [0.16 0.24]; %define time window

% find peaks time windows
s_rate = 1000; % in Hz
pre_base = 1.5; % in seconds

indx_n40 = (tw_n40 * s_rate) + (pre_base * s_rate);
indx_p60 = (tw_p60 * s_rate) + (pre_base * s_rate);
indx_n100 = (tw_n100 * s_rate) + (pre_base * s_rate);
indx_p185 = (tw_p185 * s_rate) + (pre_base * s_rate);

data_n40_lsp = mean(alldata_TEP_grand.lDLPFC_SP(:, indx_n40(1):indx_n40(2)),2);
data_p60_lsp = mean(alldata_TEP_grand.lDLPFC_SP(:, indx_p60(1):indx_p60(2)),2);
data_n100_lsp = mean(alldata_TEP_grand.lDLPFC_SP(:, indx_n100(1):indx_n100(2)),2);
data_p185_lsp = mean(alldata_TEP_grand.lDLPFC_SP(:, indx_p185(1):indx_p185(2)),2);
data_n40_ld2 = mean(alldata_TEP_grand.lDLPFC_D2(:, indx_n40(1):indx_n40(2)),2);
data_p60_ld2 = mean(alldata_TEP_grand.lDLPFC_D2(:, indx_p60(1):indx_p60(2)),2);
data_n100_ld2 = mean(alldata_TEP_grand.lDLPFC_D2(:, indx_n100(1):indx_n100(2)),2);
data_p185_ld2 = mean(alldata_TEP_grand.lDLPFC_D2(:, indx_p185(1):indx_p185(2)),2);
data_n40_ld10 = mean(alldata_TEP_grand.lDLPFC_D10(:, indx_n40(1):indx_n40(2)),2);
data_p60_ld10 = mean(alldata_TEP_grand.lDLPFC_D10(:, indx_p60(1):indx_p60(2)),2);
data_n100_ld10 = mean(alldata_TEP_grand.lDLPFC_D10(:, indx_n100(1):indx_n100(2)),2);
data_p185_ld10 = mean(alldata_TEP_grand.lDLPFC_D10(:, indx_p185(1):indx_p185(2)),2);

% make topoplots
figure
t1 = tiledlayout(3,4);
t1.TileSpacing = 'compact';
t1.Padding = 'compact';
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
nexttile
topoplot_tvh(data_n40_lsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_lsp, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_lsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_lsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_n40_ld2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_ld2, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_ld2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_ld2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_n40_ld10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_ld10, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_ld10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_ld10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(-0.21, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
cbar = colorbar('FontSize', 15, 'FontWeight', 'bold');
hv = 7.2;
lv = -7;
cbar.Ticks = [lv hv];
cbar.TickLabels = {'MIN','MAX'};
cbar.Label.String = ['Amplitude (', char(181),'V)'];
cbar.FontSize = 20;
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/topoplots/'];
%saveas(gcf,[DATAOUT, 'Topoplots_lDLPFC.png']);

data_n40_rsp = mean(alldata_TEP_grand.rDLPFC_SP(:, indx_n40(1):indx_n40(2)),2);
data_p60_rsp = mean(alldata_TEP_grand.rDLPFC_SP(:, indx_p60(1):indx_p60(2)),2);
data_n100_rsp = mean(alldata_TEP_grand.rDLPFC_SP(:, indx_n100(1):indx_n100(2)),2);
data_p185_rsp = mean(alldata_TEP_grand.rDLPFC_SP(:, indx_p185(1):indx_p185(2)),2);
data_n40_rd2 = mean(alldata_TEP_grand.rDLPFC_D2(:, indx_n40(1):indx_n40(2)),2);
data_p60_rd2 = mean(alldata_TEP_grand.rDLPFC_D2(:, indx_p60(1):indx_p60(2)),2);
data_n100_rd2 = mean(alldata_TEP_grand.rDLPFC_D2(:, indx_n100(1):indx_n100(2)),2);
data_p185_rd2 = mean(alldata_TEP_grand.rDLPFC_D2(:, indx_p185(1):indx_p185(2)),2);
data_n40_rd10 = mean(alldata_TEP_grand.rDLPFC_D10(:, indx_n40(1):indx_n40(2)),2);
data_p60_rd10 = mean(alldata_TEP_grand.rDLPFC_D10(:, indx_p60(1):indx_p60(2)),2);
data_n100_rd10 = mean(alldata_TEP_grand.rDLPFC_D10(:, indx_n100(1):indx_n100(2)),2);
data_p185_rd10 = mean(alldata_TEP_grand.rDLPFC_D10(:, indx_p185(1):indx_p185(2)),2);
figure
t2 = tiledlayout(3,4);
t2.TileSpacing = 'compact';
t2.Padding = 'compact';
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
nexttile
topoplot_tvh(data_n40_rsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_rsp, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_rsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_rsp, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_n40_rd2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_rd2, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_rd2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_rd2, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_n40_rd10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p60_rd10, EEG_chanlocs,'headrad', 0.64,'electrodes', 'on', 'shading',  'interp' );
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile 
topoplot_tvh(data_n100_rd10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight
nexttile
topoplot_tvh(data_p185_rd10, EEG_chanlocs, 'headrad', 0.64,'electrodes', 'on', 'shading',  'interp');
text(0.155, 0.195,'x', 'Color','k','FontSize',16)
axis xy; axis tight; view(0,90);
cbar = colorbar('FontSize', 15, 'FontWeight', 'bold');
hv = 7.6;
lv = -7.6;
cbar.Ticks = [lv hv];
cbar.TickLabels = {'MIN','MAX'};
cbar.Label.String = ['Amplitude (', char(181),'V)'];
cbar.FontSize = 20;
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/topoplots/'];
%saveas(gcf,[DATAOUT, 'Topoplots_rDLPFC.png']);