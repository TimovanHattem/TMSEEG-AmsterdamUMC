%% PHASE-AMPLITUDE COUPLING (PAC) ANALYSIS
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: clean epochs (*.set) & TEP master file
% OUTPUT: phase-amplitude coupling graphs

%% Clean workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/') %path to personal scratch folder, change accordingly to user
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0'); 
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

eeglab;

%% MASTER FILES MI-INDEX WITH lDLPFC/rDLPFC ROI 

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])

brs = {'lDLPFC', 'rDLPFC'}; %INPUT REQUIRED
cons = {'SP', 'D2','D10'}; %INPUT REQUIRED

alldata_PAC_master = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'rDLPFC_SP', {}, 'rDLPFC_D2', {},'rDLPFC_D10', {});
alldata_PAC_MI = struct('MI_lDLPFC_SP', {},'MI_lDLPFC_D2', {}, 'MI_lDLPFC_D10', {}, 'MI_rDLPFC_SP', {}, 'MI_rDLPFC_D2', {},'MI_rDLPFC_D10', {});

% Define the frequency bands of interest
theta_band = [4 8]; % in Hz
%beta_band = [13 30];
gamma_band = [30 50]; % in Hz

% Define the sampling rate and time points of interest
sampling_rate = 1000;

ROI_l = [3,21,31,39]; %ROI lDLPFC
ROI_r = [4,22,32,40]; %ROI rDLPFC

MI_roi = zeros(1,size(ROI_r,2));
gamma_amplitude_bins_roi = zeros(size(ROI_r,2),18);

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/'];

for br=1:size(brs,2)
    for con=1:size(cons,2)
        for i=1:size(alldata_TEP_master,2)
            alldata_PAC_master(i).ppn = alldata_TEP_master(i).ppn;
            %alldata_MI(i).ppn = alldata_TEP_master(i).ppn;

            for idx_roi= 1:size(ROI_r,2)

                if strcmpi(brs{br},'lDLPFC')
                    ch = ROI_l(idx_roi);
                else
                    ch = ROI_r(idx_roi);
                end

                if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                    time_series = alldata_TEP_master(i).lDLPFC_SP(ch,:);
                elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                    time_series = alldata_TEP_master(i).lDLPFC_D2(ch,:);
                elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                    time_series =  alldata_TEP_master(i).lDLPFC_D10(ch,:);
                elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                    time_series = alldata_TEP_master(i).rDLPFC_SP(ch,:);
                elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                    time_series = alldata_TEP_master(i).rDLPFC_D2(ch,:);
                elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                    time_series = alldata_TEP_master(i).rDLPFC_D10(ch,:);
                end
              
                time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
                %time_series_beta = eegfilt(time_series, sampling_rate, beta_band(1), beta_band(2));
                time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

                %[b,a] = butter(2, (theta_band / 500));
                %[d,c] = butter(2, (gamma_band / 500));
                %time_series_theta = filter(b,a,time_series);
                %time_series_gamma = filter(d,c, time_series);

                % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
                theta_hilbert = hilbert(time_series_theta);
                %beta_hilbert = hilbert(time_series_beta);
                gamma_hilbert = hilbert(time_series_gamma);

                theta_hilbert = theta_hilbert(1,1515:2000);
                %beta_hilbert = beta_hilbert(1,1515:2000);
                gamma_hilbert = gamma_hilbert(1,1515:2000);

                theta_phase = angle(theta_hilbert);
                %beta_amplitude = abs(beta_hilbert);
                %beta_phase = angle(beta_hilbert);
                gamma_amplitude = abs(gamma_hilbert);

                % Bin the phases into 18 equal-width bins
                n_bins = 18;
                bin_edges = linspace(-pi, pi, n_bins+1);
                bin_centers = (bin_edges(1:end-1) + bin_edges(2:end))/2;
                theta_phase_bins = discretize(theta_phase, bin_edges);

                % Compute the mean gamma amplitude in each phase bin
                gamma_amplitude_bins= zeros(1,n_bins);
                for i_bin = 1:n_bins
                    gamma_amplitude_bins(i_bin) = mean(gamma_amplitude(theta_phase_bins == i_bin));
                end

                MI = (log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log(gamma_amplitude_bins/sum(gamma_amplitude_bins)))))/log(n_bins);
                MI_roi(idx_roi) = MI;
                gamma_amplitude_bins_roi(idx_roi,:) = gamma_amplitude_bins;
            end


            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).lDLPFC_SP = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_lDLPFC_SP = mean(MI_roi);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).lDLPFC_D2 = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_lDLPFC_D2 = mean(MI_roi);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).lDLPFC_D10 = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_lDLPFC_D10 = mean(MI_roi);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).rDLPFC_SP = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_rDLPFC_SP = mean(MI_roi);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).rDLPFC_D2 = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_rDLPFC_D2 = mean(MI_roi);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).rDLPFC_D10 = mean(gamma_amplitude_bins,1);
                alldata_PAC_MI(i).MI_rDLPFC_D10 = mean(MI_roi);
            end

        end
    end
end
alldata_PAC_grand.lDLPFC_SP = mean(cat(3,alldata_PAC_master.lDLPFC_SP),3);
alldata_PAC_grand.lDLPFC_D2 = mean(cat(3,alldata_PAC_master.lDLPFC_D2),3);
alldata_PAC_grand.lDLPFC_D10 = mean(cat(3,alldata_PAC_master.lDLPFC_D10),3);
alldata_PAC_grand.rDLPFC_SP = mean(cat(3,alldata_PAC_master.rDLPFC_SP),3);
alldata_PAC_grand.rDLPFC_D2 = mean(cat(3,alldata_PAC_master.rDLPFC_D2),3);
alldata_PAC_grand.rDLPFC_D10 = mean(cat(3,alldata_PAC_master.rDLPFC_D10),3);

%save([DATAOUT, 'alldata_PAC_master.mat'], 'alldata_PAC_master');
%save([DATAOUT, 'alldata_PAC_grand.mat'], 'alldata_PAC_grand');
%save([DATAOUT, 'alldata_PAC_MI.mat'], 'alldata_PAC_MI');

%% BAR GRAPHS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/alldata_PAC_master.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/alldata_PAC_grand.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/alldata_PAC_MI.mat'])

% x = transpose(squeeze(cell2mat(struct2cell(alldata_PAC_MI))));
% figure
% boxchart(x,'BoxFaceColor', 'b' )
% title('Phase-Amplitude Plot - MI-index')
% ylabel('MI-index')
% xlabel('Condition')
% %set(gca,'XTick',[1,2,3,4,5,6], 'FontSize', 10)
% set(gca,'xticklabel',({'lDLPFC_SP', 'lDLPFC_D2','lDLPFC_D10','rDLPFC_SP','rDLPFC_D2','rDLPFC_D10',  }))

x = transpose(squeeze(cell2mat(struct2cell(alldata_PAC_MI))));
X = categorical({'lDLPFC','rDLPFC'});
X = reordercats(X,{'lDLPFC','rDLPFC'});
y = mean(x);
y = vertcat(y(1:3),y(4:6));
%err_l = reshape(std(x), [4,3]);
%err_r = reshape(std(alldata_amp_r), [4,3]);
err_l = std(x(:,1:3))/sqrt(size(x(:,1:3),1));
err_r = std(x(:,4:6))/sqrt(size(x(:,4:6),1));
err = vertcat(err_l,err_r);
figure
b = bar(X,y, 'grouped', 'EdgeColor',[0 0 0],'LineWidth',2.5);
hold on
[ngroups,nbars] = size(y);
x_bars = nan(nbars, ngroups);
for i = 1:nbars
      x_bars(i,:) = b(i).XEndPoints;
end
errorbar(x_bars',y,err,'k','linestyle','none', 'LineWidth',2.5);
hold off
b(1).FaceColor = [0 0.4470 0.7410];
b(2).FaceColor = [0.8500 0.3250 0.0980];
b(3).FaceColor = [0.9290 0.6940 0.1250];
ylim([0 0.05])
%title('Phase-Amplitude Plot - MI-index')
ylabel('Modulation Index', 'FontSize', 22, 'FontWeight', 'bold')
xlabel('Brain regions', 'FontSize', 22, 'FontWeight', 'bold')
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
axis square
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
% pause(5)
% DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/'];
% saveas(gcf,[DATAOUT, 'PAC_grand_bargraph.png']);

figure
t = tiledlayout(3,2);
t.TileSpacing = 'compact';
ylabel(t,['Gamma Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
xlabel(t,'Theta Phase (Deg)',  'FontSize', 22, 'FontWeight', 'bold')
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
nexttile
bar([alldata_PAC_grand.lDLPFC_SP],'FaceColor',[0.5 0.5 0.5], 'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_SP]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
nexttile
bar([alldata_PAC_grand.rDLPFC_SP],'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_SP]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
nexttile
bar([alldata_PAC_grand.lDLPFC_D2],'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_D2]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
nexttile
bar([alldata_PAC_grand.rDLPFC_D2],'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_D2]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
nexttile
bar([alldata_PAC_grand.lDLPFC_D10],'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_D10]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
nexttile
bar([alldata_PAC_grand.rDLPFC_D10],'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0 0 0],'LineWidth',2.5)
%title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_D10]))])
set(gca,'XTick',[1,9,18], 'FontSize', 14)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
set(gca,'box','off')
% pause(5)
% DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/'];
% saveas(gcf,[DATAOUT, 'PAC_grand_distributions.png']);

%% STATISTICS 

alldata_PAC_MI = transpose(squeeze(cell2mat(struct2cell(alldata_PAC_MI))));

[a,b] = jbtest(alldata_PAC_MI(:,1))
[a,b] = jbtest(alldata_PAC_MI(:,2))
[a,b] = jbtest(alldata_PAC_MI(:,3))
[a,b] = jbtest(alldata_PAC_MI(:,4))
[a,b] = jbtest(alldata_PAC_MI(:,5))
[a,b] = jbtest(alldata_PAC_MI(:,6))

[a,b] = vartest2(alldata_PAC_MI(:,1),alldata_PAC_MI(:,2))
[a,b] = vartest2(alldata_PAC_MI(:,1),alldata_PAC_MI(:,3))
[a,b] = vartest2(alldata_PAC_MI(:,4),alldata_PAC_MI(:,5))
[a,b] = vartest2(alldata_PAC_MI(:,4),alldata_PAC_MI(:,6))

[a,b] = vartest2(alldata_PAC_MI(:,1),alldata_PAC_MI(:,4))
[a,b] = vartest2(alldata_PAC_MI(:,2),alldata_PAC_MI(:,5))
[a,b] = vartest2(alldata_PAC_MI(:,3),alldata_PAC_MI(:,6))

[tlsici,plsici] = ttest(alldata_PAC_MI(:,1),alldata_PAC_MI(:,2))
[tlicf, plicf] = ttest(alldata_PAC_MI(:,1),alldata_PAC_MI(:,3))
[trsici,prsici] = ttest(alldata_PAC_MI(:,4),alldata_PAC_MI(:,5))
[tricf, pricf] = ttest(alldata_PAC_MI(:,4),alldata_PAC_MI(:,6))
[tlsp,plsp] = ttest(alldata_PAC_MI(:,1),alldata_PAC_MI(:,4))
[tlsici, plsici] = ttest(alldata_PAC_MI(:,2),alldata_PAC_MI(:,5))
[tlicf,plicf] = ttest(alldata_PAC_MI(:,3),alldata_PAC_MI(:,6))

alldata_pac_tab = struct2table(alldata_PAC_MI);
writetable(alldata_pac_tab, ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/PAC/alldata_pac_tab.xlsx'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% OLD/NOT USED: MI-index
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])
xx = zeros(1,9);
for i=1:size(alldata_TEP_master,2)

    time_series = alldata_TEP_master(i).rDLPFC_SP(4,:);

    % Define the frequency bands of interest
    theta_band = [4 8]; % in Hz
    beta_band = [13 30];
    gamma_band = [30 50]; % in Hz

    % Define the sampling rate and time points of interest
    sampling_rate = 1000;
    
    time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
    %time_series_beta = eegfilt(time_series, sampling_rate, beta_band(1), beta_band(2));
    time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

    % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
    theta_hilbert = hilbert(time_series_theta);
    %beta_hilbert = hilbert(time_series_beta);
    gamma_hilbert = hilbert(time_series_gamma);

    theta_hilbert = theta_hilbert(1,1515:2000);
    %beta_hilbert = beta_hilbert(1,1515:2000);
    gamma_hilbert = gamma_hilbert(1,1515:2000);

    theta_phase = angle(theta_hilbert);
    %beta_amplitude = abs(beta_hilbert);
    %beta_angle = angle(beta_hilbert);
    gamma_amplitude = abs(gamma_hilbert);

    % Bin the phases into 18 equal-width bins
    n_bins = 18;
    bin_edges = linspace(-pi, pi, n_bins+1);
    bin_centers = (bin_edges(1:end-1) + bin_edges(2:end))/2;
    theta_phase_bins = discretize(theta_phase, bin_edges);

    % Compute the mean gamma amplitude in each phase bin
    gamma_amplitude_bins = zeros(1,n_bins);
    for i_bin = 1:n_bins
        gamma_amplitude_bins(i_bin) = mean(gamma_amplitude(theta_phase_bins == i_bin));
    end

    MI=(log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log((gamma_amplitude_bins/sum(gamma_amplitude_bins))))))/log(n_bins);
    xx(1,i) = MI;

    figure
    bar(gamma_amplitude_bins)
    title(['Phase-Amplitude Plot - MI-index: ', num2str(MI)])
    ylabel('Gamma Amplitude')
    xlabel('Theta Phase (Deg)')
    set(gca,'XTick',[1,9,18], 'FontSize', 10)
    set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
    close
    %pause
end

%% OLD/NOT USED: MI-index loop

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])

brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

alldata_PAC_master = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'rDLPFC_SP', {}, 'rDLPFC_D2', {},'rDLPFC_D10', {});
alldata_PAC_MI = struct('MI_lDLPFC_SP', {},'MI_lDLPFC_D2', {}, 'MI_lDLPFC_D10', {}, 'MI_rDLPFC_SP', {}, 'MI_rDLPFC_D2', {},'MI_rDLPFC_D10', {});

% Define the frequency bands of interest
theta_band = [4 8]; % in Hz
%beta_band = [13 30];
gamma_band = [30 50]; % in Hz

% Define the sampling rate and time points of interest
sampling_rate = 1000;

for br=1:size(brs,2)
    for con=1:size(cons,2)
        for i=1:size(alldata_TEP_master,2)
            alldata_PAC_master(i).ppn = alldata_TEP_master(i).ppn;
            %alldata_MI(i).ppn = alldata_TEP_master(i).ppn;

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                time_series = alldata_TEP_master(i).lDLPFC_SP(3,:);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                time_series = alldata_TEP_master(i).lDLPFC_D2(3,:);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                time_series =  alldata_TEP_master(i).lDLPFC_D10(3,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                time_series = alldata_TEP_master(i).rDLPFC_SP(4,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                time_series = alldata_TEP_master(i).rDLPFC_D2(4,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                time_series = alldata_TEP_master(i).rDLPFC_D10(4,:);
            end

            time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
            %time_series_beta = eegfilt(time_series, sampling_rate, beta_band(1), beta_band(2));
            time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

            % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
            theta_hilbert = hilbert(time_series_theta);
            %beta_hilbert = hilbert(time_series_beta);
            gamma_hilbert = hilbert(time_series_gamma);

            theta_hilbert = theta_hilbert(1,1515:2000);
            %beta_hilbert = beta_hilbert(1,1515:2000);
            gamma_hilbert = gamma_hilbert(1,1515:2000);

            theta_phase = angle(theta_hilbert);
            %beta_amplitude = abs(beta_hilbert);
            %beta_angle = angle(beta_hilbert);
            gamma_amplitude = abs(gamma_hilbert);

            % Bin the phases into 18 equal-width bins
            n_bins = 18;
            bin_edges = linspace(-pi, pi, n_bins+1);
            bin_centers = (bin_edges(1:end-1) + bin_edges(2:end))/2;
            theta_phase_bins = discretize(theta_phase, bin_edges);

            % Compute the mean gamma amplitude in each phase bin
            gamma_amplitude_bins= zeros(1,n_bins);
            for i_bin = 1:n_bins
                gamma_amplitude_bins(i_bin) = mean(gamma_amplitude(theta_phase_bins == i_bin));
            end

            MI=(log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log((gamma_amplitude_bins/sum(gamma_amplitude_bins))))))/log(n_bins);

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).lDLPFC_SP = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_SP = MI;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).lDLPFC_D2 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_D2 = MI;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).lDLPFC_D10 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_D10 = MI;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).rDLPFC_SP = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_SP = MI;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).rDLPFC_D2 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_D2 = MI;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).rDLPFC_D10 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_D10 = MI;
            end

        end
    end
end

alldata_PAC_grand.lDLPFC_SP = mean(cat(3,alldata_PAC_master.lDLPFC_SP),3);
alldata_PAC_grand.lDLPFC_D2 = mean(cat(3,alldata_PAC_master.lDLPFC_D2),3);
alldata_PAC_grand.lDLPFC_D10 = mean(cat(3,alldata_PAC_master.lDLPFC_D10),3);
alldata_PAC_grand.rDLPFC_SP = mean(cat(3,alldata_PAC_master.rDLPFC_SP),3);
alldata_PAC_grand.rDLPFC_D2 = mean(cat(3,alldata_PAC_master.rDLPFC_D2),3);
alldata_PAC_grand.rDLPFC_D10 = mean(cat(3,alldata_PAC_master.rDLPFC_D10),3);

x = transpose(squeeze(cell2mat(struct2cell(alldata_PAC_MI))));
figure
boxchart(x,'BoxFaceColor', 'b' )
title('Phase-Amplitude Plot - MI-index')
ylabel('MI-index')
xlabel('Condition')
%set(gca,'XTick',[1,2,3,4,5,6], 'FontSize', 10)
set(gca,'xticklabel',({'lDLPFC_SP', 'lDLPFC_D2','lDLPFC_D10','rDLPFC_SP','rDLPFC_D2','rDLPFC_D10',  }))

figure
subplot(3,2,1)
bar([alldata_PAC_grand.lDLPFC_SP])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_SP]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
subplot(3,2,2)
bar([alldata_PAC_grand.rDLPFC_SP])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_SP]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
subplot(3,2,3)
bar([alldata_PAC_grand.lDLPFC_D2])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_D2]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
subplot(3,2,4)
bar([alldata_PAC_grand.rDLPFC_D2])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_D2]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
subplot(3,2,5)
bar([alldata_PAC_grand.lDLPFC_D10])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_lDLPFC_D10]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))
subplot(3,2,6)
bar([alldata_PAC_grand.rDLPFC_D10])
title(['Phase-Amplitude Plot - MI-index: ', num2str(mean([alldata_PAC_MI.MI_rDLPFC_D10]))])
ylabel('Gamma Amplitude')
xlabel('Theta Phase (Deg)')
set(gca,'XTick',[1,9,18], 'FontSize', 10)
set(gca,'xticklabel',({['-180', char(176)], ['0',char(176)], ['180',char(176)]}))

%% OLD/NOT USED: MVL polarplot

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])
xx = zeros(1,9);
for i=1:size(alldata_TEP_master,2)

    time_series = alldata_TEP_master(i).rDLPFC_SP(4,:);

    % Define the frequency bands of interest
    theta_band = [4 8]; % in Hz
    beta_band = [13 30];
    gamma_band = [30 50]; % in Hz

    % Define the sampling rate and time points of interest
    sampling_rate = 1000;
    
    time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
    %time_series_beta = eegfilt(time_series, sampling_rate, beta_band(1), beta_band(2));
    time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

    % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
    theta_hilbert = hilbert(time_series_theta);
    %beta_hilbert = hilbert(time_series_beta);
    gamma_hilbert = hilbert(time_series_gamma);

    theta_hilbert = theta_hilbert(1,1515:2000);
    %beta_hilbert = beta_hilbert(1,1515:2000);
    gamma_hilbert = gamma_hilbert(1,1515:2000);

    theta_phase = angle(theta_hilbert);
    %beta_amplitude = abs(beta_hilbert);
    %beta_angle = angle(beta_hilbert);
    gamma_amplitude = abs(gamma_hilbert);

    figure
    polarplot(theta_phase,gamma_amplitude, '*' )
    %pause
end

%% OLD/NOT USED: MI-index loop surrogate control

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])

brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

alldata_PAC_master = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'rDLPFC_SP', {}, 'rDLPFC_D2', {},'rDLPFC_D10', {});
alldata_PAC_MI = struct('MI_lDLPFC_SP', {},'MI_lDLPFC_D2', {}, 'MI_lDLPFC_D10', {}, 'MI_rDLPFC_SP', {}, 'MI_rDLPFC_D2', {},'MI_rDLPFC_D10', {});
alldata_MI_news = struct('MI_lDLPFC_SP', {},'MI_lDLPFC_D2', {}, 'MI_lDLPFC_D10', {}, 'MI_rDLPFC_SP', {}, 'MI_rDLPFC_D2', {},'MI_rDLPFC_D10', {});

MI_news = [];

% Define the frequency bands of interest
theta_band = [4 8]; % in Hz
beta_band = [13 30];
gamma_band = [30 50]; % in Hz

% Define the sampling rate and time points of interest
sampling_rate = 1000;

for br=1:size(brs,2)
    for con=1:size(cons,2)
        for i=1:size(alldata_TEP_master,2)
            alldata_PAC_master(i).ppn = alldata_TEP_master(i).ppn;
            %alldata_MI(i).ppn = alldata_TEP_master(i).ppn;


            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                time_series = alldata_TEP_master(i).lDLPFC_SP(3,:);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                time_series = alldata_TEP_master(i).lDLPFC_D2(3,:);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                time_series =  alldata_TEP_master(i).lDLPFC_D10(3,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                time_series = alldata_TEP_master(i).rDLPFC_SP(4,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                time_series = alldata_TEP_master(i).rDLPFC_D2(4,:);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                time_series = alldata_TEP_master(i).rDLPFC_D10(4,:);
            end

            time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
            %time_series_beta = eegfilt(time_series, sampling_rate, beta_band(1), beta_band(2));
            time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

            % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
            theta_hilbert = hilbert(time_series_theta);
            %beta_hilbert = hilbert(time_series_beta);
            gamma_hilbert = hilbert(time_series_gamma);

            theta_hilbert = theta_hilbert(1,1515:2000);
            %beta_hilbert = beta_hilbert(1,1515:2000);
            gamma_hilbert = gamma_hilbert(1,1515:2000);

            theta_phase = angle(theta_hilbert);
            %beta_amplitude = abs(beta_hilbert);
            %beta_angle = angle(beta_hilbert);
            gamma_amplitude = abs(gamma_hilbert);

            % Bin the phases into 18 equal-width bins
            n_bins = 18;
            bin_edges = linspace(-pi, pi, n_bins+1);
            bin_centers = (bin_edges(1:end-1) + bin_edges(2:end))/2;
            theta_phase_bins = discretize(theta_phase, bin_edges);

            % Compute the mean gamma amplitude in each phase bin
            gamma_amplitude_bins= zeros(1,n_bins);
            for i_bin = 1:n_bins
                gamma_amplitude_bins(i_bin) = mean(gamma_amplitude(theta_phase_bins == i_bin));
            end
            MI=(log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log((gamma_amplitude_bins/sum(gamma_amplitude_bins))))))/log(n_bins);

            for j = 1:200
                data = gamma_amplitude(randperm(length(gamma_amplitude)));

                gamma_amplitude_bins= zeros(1,n_bins);
                for i_bin = 1:n_bins
                    gamma_amplitude_bins(i_bin) = mean(data(theta_phase_bins == i_bin));
                end
                MI_new=(log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log((gamma_amplitude_bins/sum(gamma_amplitude_bins))))))/log(n_bins);
                MI_news(j) = MI_new;
            end

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).lDLPFC_SP = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_SP = MI;
                alldata_MI_news(i).MI_lDLPFC_SP = MI_news;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).lDLPFC_D2 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_D2 = MI;
                alldata_MI_news(i).MI_lDLPFC_D2 = MI_news;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).lDLPFC_D10 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_lDLPFC_D10 = MI;
                alldata_MI_news(i).MI_lDLPFC_D10 = MI_news;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_master(i).rDLPFC_SP = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_SP = MI;
                alldata_MI_news(i).MI_rDLPFC_SP = MI_news;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_master(i).rDLPFC_D2 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_D2 = MI;
                alldata_MI_news(i).MI_rDLPFC_D2 = MI_news;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_master(i).rDLPFC_D10 = gamma_amplitude_bins;
                alldata_PAC_MI(i).MI_rDLPFC_D10 = MI;
                alldata_MI_news(i).MI_rDLPFC_D10 = MI_news;
            end
        end
    end
end

for br=1:size(brs,2)
    for con=1:size(cons,2)
        for i=1:size(alldata_MI_news,2)
            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                val = alldata_PAC_MI(i).MI_lDLPFC_SP;
                data = [alldata_MI_news(i).MI_lDLPFC_SP];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_lDLPFC_SP = newval;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                val = alldata_PAC_MI(i).MI_lDLPFC_D2;
                data = [alldata_MI_news(i).MI_lDLPFC_D2];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_lDLPFC_D2 = newval;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                val = alldata_PAC_MI(i).MI_lDLPFC_SP;
                data = [alldata_MI_news(i).MI_lDLPFC_D10];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_lDLPFC_D10 = newval;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                val = alldata_PAC_MI(i).MI_lDLPFC_SP;
                data = [alldata_MI_news(i).MI_rDLPFC_SP];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_rDLPFC_SP = newval;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                val = alldata_PAC_MI(i).MI_lDLPFC_SP;
                data = [alldata_MI_news(i).MI_rDLPFC_D2];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_rDLPFC_D2 = newval;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                val = alldata_PAC_MI(i).MI_lDLPFC_SP;
                data = [alldata_MI_news(i).MI_rDLPFC_D10];
                newval = (val - mean(data)) / std(data);
                alldata_PAC_MI(i).MI_rDLPFC_D10 = newval;
            end
        end
    end
end

%% OLD/NOT USED: Epoch level PAC

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'};
brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

alldata_PAC_MI = struct('MI_lDLPFC_SP', {},'MI_lDLPFC_D2', {}, 'MI_lDLPFC_D10', {}, 'MI_rDLPFC_SP', {}, 'MI_rDLPFC_D2', {},'MI_rDLPFC_D10', {});

theta_band = [4 8]; % in Hz
%beta_band = [13 30];
gamma_band = [30 50]; % in Hz

% Define the sampling rate and time points of interest
sampling_rate = 1000;

for ppn=1:size(ppns,2)   
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            for idx= 1:size(EEG.data,3)
                if idx == 1
                    MIxx = zeros(1, size(EEG.data,3));
                end

                if strcmpi(brs{br},'lDLPFC')
                    ch = 3;
                else
                    ch = 4;
                end

                time_series = EEG.data(ch,:,idx);

                time_series_theta = eegfilt(time_series, sampling_rate, theta_band(1), theta_band(2));
                time_series_gamma = eegfilt(time_series, sampling_rate, gamma_band(1), gamma_band(2));

                % Compute the Hilbert transform of the time series to obtain the instantaneous phase and amplitude
                theta_hilbert = hilbert(time_series_theta);
                %beta_hilbert = hilbert(time_series_beta);
                gamma_hilbert = hilbert(time_series_gamma);

                theta_hilbert = theta_hilbert(1,1515:2000);
                %beta_hilbert = beta_hilbert(1,1515:2000);
                gamma_hilbert = gamma_hilbert(1,1515:2000);

                theta_phase = angle(theta_hilbert);
                %beta_amplitude = abs(beta_hilbert);
                %beta_angle = angle(beta_hilbert);
                gamma_amplitude = abs(gamma_hilbert);
                %gamma_phase = angle(gamma_hilbert);

                % Bin the phases into 18 equal-width bins
                n_bins = 18;
                bin_edges = linspace(-pi, pi, n_bins+1);
                bin_centers = (bin_edges(1:end-1) + bin_edges(2:end))/2;
                theta_phase_bins = discretize(theta_phase, bin_edges);

                % Compute the mean gamma amplitude in each phase bin
                gamma_amplitude_bins= zeros(1,n_bins);
                for i_bin = 1:n_bins
                    gamma_amplitude_bins(i_bin) = mean(gamma_amplitude(theta_phase_bins == i_bin));
                end

                MI = (log(n_bins)-(-sum((gamma_amplitude_bins/sum(gamma_amplitude_bins)).*log((gamma_amplitude_bins/sum(gamma_amplitude_bins))))))/log(n_bins);
                
                MIxx(1,idx) = MI;

            end

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_MI(ppn).MI_lDLPFC_SP = MIxx;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_MI(ppn).MI_lDLPFC_D2 = MIxx;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_MI(ppn).MI_lDLPFC_D10 = MIxx;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_PAC_MI(ppn).MI_rDLPFC_SP = MIxx;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_PAC_MI(ppn).MI_rDLPFC_D2 = MIxx;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_PAC_MI(ppn).MI_rDLPFC_D10 = MIxx;
            end



        end
    end
end
% %save([DATAOUT, 'alldata_TFA_master.mat'], 'alldata_TFA_master');
% %save([DATAOUT, 'TFA_times.mat'], 'times');
% %save([DATAOUT, 'TFA_frequencies.mat'], 'frequencies');
%
% alldata_TFA_grand.lDLPFC_SP = mean(cat(3,alldata_TFA_master.lDLPFC_SP),3);
% alldata_TFA_grand.lDLPFC_D2 = mean(cat(3,alldata_TFA_master.lDLPFC_D2),3);
% alldata_TFA_grand.lDLPFC_D10 = mean(cat(3,alldata_TFA_master.lDLPFC_D10),3);
% alldata_TFA_grand.rDLPFC_SP = mean(cat(3,alldata_TFA_master.rDLPFC_SP),3);
% alldata_TFA_grand.rDLPFC_D2 = mean(cat(3,alldata_TFA_master.rDLPFC_D2),3);
% alldata_TFA_grand.rDLPFC_D10 = mean(cat(3,alldata_TFA_master.rDLPFC_D10),3);
% %save([DATAOUT, 'alldata_TFA_grand.mat'], 'alldata_TFA_grand');

for i=1:9
    alldata_PAC_MI(i).MI_lDLPFC_SP = mean([alldata_PAC_MI(i).MI_lDLPFC_SP]);
    alldata_PAC_MI(i).MI_lDLPFC_D2 = mean([alldata_PAC_MI(i).MI_lDLPFC_D2]);
    alldata_PAC_MI(i).MI_lDLPFC_D10 = mean([alldata_PAC_MI(i).MI_lDLPFC_D10]);
    alldata_PAC_MI(i).MI_rDLPFC_SP = mean([alldata_PAC_MI(i).MI_rDLPFC_SP]);
    alldata_PAC_MI(i).MI_rDLPFC_D2 = mean([alldata_PAC_MI(i).MI_rDLPFC_D2]);
    alldata_PAC_MI(i).MI_rDLPFC_D10 = mean([alldata_PAC_MI(i).MI_rDLPFC_D10]);
end
