%% SPECTRAL (TFA) ANALYSIS
%
% Made by Timo van Hattem (timovanhattem@gmail.com)
% Last updated: 29-9-2023
%
% INPUT: clean epochs (*.set)
% OUTPUT: spectograms

%% Clean workspace
clear
close all
clc

%% Set paths
cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/') %path to personal scratch folder, change accordingly to user
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0'); 
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

eeglab;

%% CREATE MASTER FILE SINGLE ELECTRODES (F3/F4)

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'}; %INPUT REQUIRED
brs = {'lDLPFC', 'rDLPFC'}; %INPUT REQUIRED
cons = {'SP', 'D2','D10'}; %INPUT REQUIRED

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/'];

freq_range = [2 45]; % Frequency range of interest (in Hz)
freq_res = 0.25;
num_frex = floor((diff(freq_range) / freq_res) +  1); % Number of frequencies to examine
min_cycle = 3; % Minimum number of cycles per frequency
max_cycle = 15; % Maximum number of cycles per frequency
baseline_time = [-0.8 -0.11]; % Baseline period (in seconds)
winsize = 1500;
ntimesout = 200;

alldata_TFA_master = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'rDLPFC_SP', {}, 'rDLPFC_D2', {},'rDLPFC_D10', {});

for ppn=1:size(ppns,2)
    alldata_TFA_master(ppn).ppn = ppns{ppn};
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            if strcmpi(brs{br},'lDLPFC')
                ch = 3; %F3
            else
                ch = 4; %F4
            end
                        
            figure
            [ersp, ~, ~, times, frequencies] = pop_newtimef(EEG, 1, ch, [EEG.xmin EEG.xmax]*1000, [min_cycle max_cycle], 'caption', EEG.chanlocs(ch).labels, 'baseline', baseline_time*1000, 'freqs', freq_range, 'plotersp', 'on', 'plotitc' , 'off', 'plotphase', 'off', 'padratio', 1, 'basenorm', 'off', 'trialbase', 'off', 'winsize', winsize, 'nfreqs', num_frex, 'ntimesout', ntimesout, 'freqscale', 'linear', 'erspmax', 5);
            %saveas(gcf, [DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TFA_', EEG.chanlocs(ch).labels, '.jpg']);

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TFA_master(ppn).lDLPFC_SP = ersp;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TFA_master(ppn).lDLPFC_D2 = ersp;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TFA_master(ppn).lDLPFC_D10 = ersp;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TFA_master(ppn).rDLPFC_SP = ersp;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TFA_master(ppn).rDLPFC_D2 = ersp;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TFA_master(ppn).rDLPFC_D10 = ersp;
            end

            close
        end
    end
end
%save([DATAOUT, 'alldata_TFA_master.mat'], 'alldata_TFA_master');
%save([DATAOUT, 'TFA_times.mat'], 'times');
%save([DATAOUT, 'TFA_frequencies.mat'], 'frequencies');

alldata_TFA_grand.lDLPFC_SP = mean(cat(3,alldata_TFA_master.lDLPFC_SP),3);
alldata_TFA_grand.lDLPFC_D2 = mean(cat(3,alldata_TFA_master.lDLPFC_D2),3);
alldata_TFA_grand.lDLPFC_D10 = mean(cat(3,alldata_TFA_master.lDLPFC_D10),3);
alldata_TFA_grand.rDLPFC_SP = mean(cat(3,alldata_TFA_master.rDLPFC_SP),3);
alldata_TFA_grand.rDLPFC_D2 = mean(cat(3,alldata_TFA_master.rDLPFC_D2),3);
alldata_TFA_grand.rDLPFC_D10 = mean(cat(3,alldata_TFA_master.rDLPFC_D10),3);
%save([DATAOUT, 'alldata_TFA_grand.mat'], 'alldata_TFA_grand');

%% CREATE MASTER FILE lDLPFC/rDLPFC ROI

roi_l = [3,21,31,39]; %ROI lDLPFC: F1, F3, FC1, FC3
roi_r = [4,22,32,40]; %ROI rDLPFC: F2, F4, FC2, FC4

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'};
brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/'];

freq_range = [2 45]; % Frequency range of interest (in Hz)
freq_res = 0.25;
num_frex = floor((diff(freq_range) / freq_res) +  1); % Number of frequencies to examine
min_cycle = 3; % Minimum number of cycles per frequency
max_cycle = 15; % Maximum number of cycles per frequency
baseline_time = [-0.8 -0.11]; % Baseline period (in seconds)
winsize = 1500;
ntimesout = 200;

alldata_TFA_master_roi = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'rDLPFC_SP', {}, 'rDLPFC_D2', {},'rDLPFC_D10', {});
ersp_tot = zeros(num_frex,ntimesout, size(roi_r,2));

for ppn=1:size(ppns,2)
    alldata_TFA_master_roi(ppn).ppn = ppns{ppn};
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            for idx_roi= 1:size(roi_r,2)

                if strcmpi(brs{br},'lDLPFC')
                    ch = roi_l(idx_roi);
                else
                    ch = roi_r(idx_roi);
                end

                figure
                [ersp, ~, ~, times, frequencies] = pop_newtimef(EEG, 1, ch, [EEG.xmin EEG.xmax]*1000, [min_cycle max_cycle], 'caption', EEG.chanlocs(ch).labels, 'baseline', baseline_time*1000, 'freqs', freq_range, 'plotersp', 'on', 'plotitc' , 'off', 'plotphase', 'off', 'padratio', 1, 'basenorm', 'off', 'trialbase', 'off', 'winsize', winsize, 'nfreqs', num_frex, 'ntimesout', ntimesout, 'freqscale', 'linear', 'erspmax', 5);
                %saveas(gcf, [DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TFA_', EEG.chanlocs(ch).labels, '.jpg']);
                ersp_tot(:,:,idx_roi) = ersp;
                close all
            end

            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TFA_master_roi(ppn).lDLPFC_SP = mean(ersp_tot,3);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TFA_master_roi(ppn).lDLPFC_D2 = mean(ersp_tot,3);
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TFA_master_roi(ppn).lDLPFC_D10 = mean(ersp_tot,3);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TFA_master_roi(ppn).rDLPFC_SP = mean(ersp_tot,3);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TFA_master_roi(ppn).rDLPFC_D2 = mean(ersp_tot,3);
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TFA_master_roi(ppn).rDLPFC_D10 = mean(ersp_tot,3);
            end

           
        end
    end
end
%save([DATAOUT, 'alldata_TFA_master_roi.mat'], 'alldata_TFA_master_roi');
%save([DATAOUT, 'TFA_times.mat'], 'times');
%save([DATAOUT, 'TFA_frequencies.mat'], 'frequencies');

alldata_TFA_grand_roi.lDLPFC_SP = mean(cat(3,alldata_TFA_master_roi.lDLPFC_SP),3);
alldata_TFA_grand_roi.lDLPFC_D2 = mean(cat(3,alldata_TFA_master_roi.lDLPFC_D2),3);
alldata_TFA_grand_roi.lDLPFC_D10 = mean(cat(3,alldata_TFA_master_roi.lDLPFC_D10),3);
alldata_TFA_grand_roi.rDLPFC_SP = mean(cat(3,alldata_TFA_master_roi.rDLPFC_SP),3);
alldata_TFA_grand_roi.rDLPFC_D2 = mean(cat(3,alldata_TFA_master_roi.rDLPFC_D2),3);
alldata_TFA_grand_roi.rDLPFC_D10 = mean(cat(3,alldata_TFA_master_roi.rDLPFC_D10),3);
%save([DATAOUT, 'alldata_TFA_grand_roi.mat'], 'alldata_TFA_grand_roi');

%% GRAND-AVERAGE SPECTROGRAMS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/alldata_TFA_grand_roi.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_times.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_frequencies.mat'])

figure
t1 = tiledlayout(3,1);
t1.TileSpacing = 'compact';
t1.Padding = 'compact';
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.lDLPFC_SP,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.lDLPFC_D2,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.lDLPFC_D10,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
set(gca, 'LineWidth',5)

%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/'];
%saveas(gcf,[DATAOUT, 'TFA_grand_lDLPFC.png']);

figure
t2 = tiledlayout(3,1);
t2.TileSpacing = 'compact';
t2.Padding = 'compact';
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.rDLPFC_SP,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.rDLPFC_D2,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,alldata_TFA_grand_roi.rDLPFC_D10,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
set(gca, 'LineWidth',5)

%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/'];
%saveas(gcf,[DATAOUT, 'TFA_grand_rDLPFC.png']);

%% STATISTICS: CLUSTER-BASED PERMUTATION TEST + CONTRAST PLOTS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/alldata_TFA_master_roi.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/alldata_TFA_grand_roi.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_times.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_frequencies.mat'])

d = true;
p = 0.05;
num_permutations = 512;
t = true;
num_clusters = [];

x1 = cat(3,alldata_TFA_master_roi.lDLPFC_SP); %input
y1 = cat(3,alldata_TFA_master_roi.lDLPFC_D2); %input
x2 = cat(3,alldata_TFA_master_roi.lDLPFC_SP); %input
y2 = cat(3,alldata_TFA_master_roi.lDLPFC_D10); %input
x3 = cat(3,alldata_TFA_master_roi.rDLPFC_SP); %input
y3 = cat(3,alldata_TFA_master_roi.rDLPFC_D10); %input

[clusters1, p_values1, t_sums1, permutation_distribution1 ] = permutest(x1, y1, d, p, num_permutations, t, num_clusters);
[clusters2, p_values2, t_sums2, permutation_distribution2 ] = permutest(x2, y2, d, p, num_permutations, t, num_clusters);
[clusters3, p_values3, t_sums3, permutation_distribution3 ] = permutest(x3, y3, d, p, num_permutations, t, num_clusters);
 
figure
t = tiledlayout(3,1);
t.TileSpacing = 'compact';
t.Padding = 'compact';
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,(alldata_TFA_grand_roi.lDLPFC_SP-alldata_TFA_grand_roi.lDLPFC_D2),'EdgeColor','none') %input
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-2 2]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
hold on
sig_clus = zeros(173,200);
sig_clus(clusters1{1}) = 500;
contour3(times, frequencies, sig_clus, 'Color', 'k', 'LineWidth', 0.15, 'LineStyle', '-');
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,(alldata_TFA_grand_roi.lDLPFC_SP-alldata_TFA_grand_roi.lDLPFC_D10),'EdgeColor','none') %input
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-2 2]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
hold on
sig_clus = zeros(173,200);
sig_clus(clusters2{1}) = 500;
contour3(times, frequencies, sig_clus, 'Color', 'k', 'LineWidth', 0.15, 'LineStyle', '-');
set(gca, 'LineWidth',5)

nexttile
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2.5)
hold on
surf(times,frequencies,(alldata_TFA_grand_roi.rDLPFC_SP-alldata_TFA_grand_roi.rDLPFC_D10),'EdgeColor','none') %input
shading interp
axis xy; axis tight; view(0,90);
set(gca,'XTick',[-600,-300,0,300,600])
set(gca,'xticklabel',({'-600', '-300', '0', '300', '600'}))
set(gca, 'FontSize', 14)
xlabel('Time (ms)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
c = colorbar;
%ylim([2 30])
clim([-2 2]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 16;
c.Label.FontWeight = 'bold';
axis square 
hold on
sig_clus = zeros(173,200);
sig_clus(clusters3{1}) = 500;
contour3(times, frequencies, sig_clus, 'Color', 'k', 'LineWidth', 0.15, 'LineStyle', '-');
hold on
sig_clus = zeros(173,200);
sig_clus(clusters3{2}) = 500;
contour3(times, frequencies, sig_clus, 'Color', 'k', 'LineWidth', 0.15, 'LineStyle', '-');
set(gca, 'LineWidth',5)

%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/'];
%saveas(gcf,[DATAOUT, 'TFA_contrasts.png']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% OLD: BANDPOWERS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])
pwelletje1= zeros(9,513);
pwelletje2=zeros(9,513);
for i=1:size(alldata_TEP_master,2)

    ERP_average_stim_evoked = alldata_TEP_master(i).lDLPFC_SP(17,1500:2000);
    ERP_average_sham_evoked = alldata_TEP_master(i).rDLPFC_SP(17,1500:2000);

    % Pwelch for every line
    theta_range = [4 8];
    beta_range = [12 30];
    total_range = [0.3 45];
    window = 125;
    nooverlap = [];
    fftsize = 2^10;
    Fs = 512;

    [Pwel_stim, Fwel_stim] = pwelch(ERP_average_stim_evoked,window,nooverlap,fftsize,Fs);
    pwelletje1(i,:) = Pwel_stim';
    [Pwel_sham, Fwel_sham] = pwelch(ERP_average_sham_evoked,window,nooverlap,fftsize,Fs);
    pwelletje2(i,:) = Pwel_sham';
end

meanpower_stim = mean(pwelletje1, 1);
meanpower_sham = mean(pwelletje2,1);

% Plot Power spectrum
figure(1)
plot(Fwel_stim,10*log10(meanpower_stim), 'LineWidth', 1.15, 'Color', 'blue')                % Plot for the baseline window
hold on
plot(Fwel_sham,10*log10(meanpower_sham), 'LineWidth', 1.15, 'Color', 'red')            % Plot for the presentation window
line([theta_range(1) theta_range(1)], [-40 20], 'Color', 'black', 'LineStyle', '--'); %Create a tick mark at x = t1(i) with a height of 100
line([theta_range(2) theta_range(2)], [-40 20], 'Color', 'black', 'LineStyle', '--'); %Create a tick mark at x = t1(i) with a height of 100
xlim([2 45])
ylim([-40 10])
%title('PSD', 'FontSize', 12,'FontWeight', 'bold' )
xlabel('Frequency (Hz)','FontSize', 18,'FontWeight', 'bold')
ylabel('Power (dB)', 'FontSize', 18, 'FontWeight', 'bold')
axis square 
%a = line([PSD_info_allpp(1).FwelStim(1) PSD_info_allpp(1).FwelStim(38)], [-39.15 -39.15], 'Color', 'black', 'LineWidth', 15.2);
a.Color(4) = 0.3;
legend('Stimulation','Sham', 'FontSize', 18, 'FontWeight', 'bold')
set(gca,'box','off')
set(gca,'FontSize',14)

% figure(2)
% plot(PSD_info_allpp(1).FwelStim,meanpower_ratio, 'LineWidth', 1.15)
% %line([1 40], [1 1], 'Color', 'black','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
% yline(1, '--', 'y = 1', 'FontSize', 12)
% xlim([2 30])
% ylim([-1 11])
% %title('Power ratio Stimulation/Sham', 'FontSize', 12,'FontWeight', 'bold' )
% xlabel('Frequency (Hz)','FontSize', 18,'FontWeight', 'bold')
% ylabel('Relative power (Stimulation/Sham)','FontSize', 18, 'FontWeight', 'bold')
% axis square
% set(gca,'box','off')
% set(gca,'FontSize',14)

%% OLD: Check all individual plots
%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_times.mat'])
%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/TFA_frequencies.mat'])
%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TFA/alldata_TFA_master.mat'])

figure
colormap(jet(256))
plot3([0 0],[2 45],[0 1000],'w','LineWidth',2)
hold on
% plot3([0 600],[8 8],[0 200],'--w','LineWidth',1)
% hold on
% plot3([0 600],[12 12],[0 200],'--w','LineWidth',1)
% hold on
surf(times,frequencies,alldata_TFA_master(6).lDLPFC_SP,'EdgeColor','none')
shading interp
axis xy; axis tight; view(0,90);
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('Frequency (Hz)', 'FontSize', 10, 'FontWeight', 'bold');
title('Spectrogram', 'FontSize', 12, 'FontWeight', 'bold')
c = colorbar;
%ylim([2 30])
clim([-3 3]);
c.Label.String = 'Power (dB)';
c.Label.FontSize = 10;
c.Label.FontWeight = 'bold';
axis square 
%set(gca,'FontSize',14)
%set(gca,'xticklabel',({'-200', '0', '200', '400', '600', '800'}))



