% TEP PLOTS
%
% Timo van Hattem
% Updated: 13-3-2023

cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')
%% Clean workspace
clear
close all
clc

%% Set paths
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0'); 
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

eeglab;

%% LOOP TEP PLOTS INDIVIDUAL LEVEL

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'};
brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];

for ppn=1:size(ppns,2)
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            % Butterfly plot
            pop_tesa_plot(EEG, 'elec', [], 'tepType', 'data', 'xlim', [-100 400], 'ylim', [-20 20], 'CI', 'off', 'plotPeak', 'off');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_Butterfly.jpg']);

            % FZ
            pop_tesa_plot(EEG, 'elec', ['FZ'], 'tepType', 'data', 'xlim', [-100 400], 'ylim', [-20 20], 'CI', 'off', 'plotPeak', 'off');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_FZ.jpg']);

            % CZ
            pop_tesa_plot(EEG, 'elec', ['CZ'], 'tepType', 'data', 'xlim', [-100 400], 'ylim', [-20 20], 'CI', 'off', 'plotPeak', 'off');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_CZ.jpg']);

            % F3
            pop_tesa_plot(EEG, 'elec', ['F3'], 'tepType', 'data', 'xlim', [-100 400], 'ylim', [-20 20], 'CI', 'off', 'plotPeak', 'off');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_F3.jpg']);

            % F4
            pop_tesa_plot(EEG, 'elec', ['F4'], 'tepType', 'data', 'xlim', [-100 400], 'ylim', [-20 20], 'CI', 'off', 'plotPeak', 'off');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_F4.jpg']);

            % F3-ROI
            EEG_l = pop_tesa_tepextract(EEG, 'ROI', 'elecs', {'F3','F1', 'FC3', 'AF3'}, 'tepName', 'lDLPFC' );
            EEG_l = pop_tesa_peakanalysis(EEG_l, 'ROI', 'positive', [60 185], [55 75;160 240], 'method', 'largest', 'samples', 5 );
            EEG_l = pop_tesa_peakanalysis(EEG_l, 'ROI', 'negative', [40 100], [30 50;90 140], 'method', 'largest', 'samples', 5 );
            pop_tesa_plot(EEG_l, 'tepType', 'ROI', 'tepName', 'lDLPFC', 'xlim', [-100 400], 'ylim', [-20 20], 'CI','off','plotPeak','on' );
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_F3-ROI.jpg']);

            % F4-ROI
            EEG_r = pop_tesa_tepextract(EEG, 'ROI', 'elecs', {'F4','F2', 'FC4', 'AF4'}, 'tepName', 'rDLPFC' );
            EEG_r = pop_tesa_peakanalysis(EEG_r, 'ROI', 'positive', [60 185], [55 75;160 240], 'method', 'largest', 'samples', 5 );
            EEG_r = pop_tesa_peakanalysis( EEG_r, 'ROI', 'negative', [40 100], [30 50;90 140], 'method', 'largest', 'samples', 5 );
            pop_tesa_plot(EEG_r, 'tepType', 'ROI', 'tepName', 'rDLPFC', 'xlim', [-100 400], 'ylim', [-20 20], 'CI','off','plotPeak','on' );
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_F4-ROI.jpg']);

            % GMFA
            EEG = pop_tesa_tepextract(EEG, 'GMFA');
            pop_tesa_plot(EEG, 'tepType', 'GMFA');
            saveas(gcf,[DATAOUT, ppns{ppn}, '_', brs{br}, '_', cons{con}, '_TEP_GMFA.jpg']);

            close all
        end
    end
end

%% CREATE MASTER FILE ALLDATA

ppns = {'pilot_80%'};
brs = {'M1'};
cons = {'SP', 'D2','D10','SP80' };
alldata_TEP_master = struct('ppn', {}, 'lDLPFC_SP', {},'lDLPFC_D2', {}, 'lDLPFC_D10', {}, 'lDLPFC_SP80', {});

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];

for ppn=1:size(ppns,2)
    alldata_TEP_master(ppn).ppn = ppns{ppn};
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);
            mean_TEP_allchan = mean(EEG.data,3);
            if strcmpi(brs{br}, 'M1') && strcmpi(cons{con}, 'SP')
                alldata_TEP_master(ppn).lDLPFC_SP = mean_TEP_allchan;
            elseif strcmpi(brs{br}, 'M1') && strcmpi(cons{con}, 'D2')
                alldata_TEP_master(ppn).lDLPFC_D2 = mean_TEP_allchan;
            elseif strcmpi(brs{br}, 'M1') && strcmpi(cons{con}, 'D10')
                alldata_TEP_master(ppn).lDLPFC_D10 = mean_TEP_allchan;
            elseif strcmpi(brs{br}, 'M1') && strcmpi(cons{con}, 'SP80')
                alldata_TEP_master(ppn).lDLPFC_SP80 = mean_TEP_allchan;
            end
        end
    end
end
%save([DATAOUT, 'alldata_TEP_master.mat'], 'alldata_TEP_master');

alldata_TEP_grand.lDLPFC_SP = mean(cat(3,alldata_TEP_master.lDLPFC_SP),3);
alldata_TEP_grand.lDLPFC_D2 = mean(cat(3,alldata_TEP_master.lDLPFC_D2),3);
alldata_TEP_grand.lDLPFC_D10 = mean(cat(3,alldata_TEP_master.lDLPFC_D10),3);
alldata_TEP_grand.lDLPFC_SP80 = mean(cat(3,alldata_TEP_master.lDLPFC_SP80),3);
%save([DATAOUT, 'alldata_TEP_grand.mat'], 'alldata_TEP_grand');


%% GRAND AVERAGE TEP PLOTS F3/F4

%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_grand.mat'])

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_grand.lDLPFC_SP(5,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.lDLPFC_D2(5,:)], 'r','LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.lDLPFC_D10(5,:)], 'g','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')
%%
figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_grand.rDLPFC_SP(4,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.rDLPFC_D2(4,:)], 'r','LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.rDLPFC_D10(4,:)], 'g','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_grand.lDLPFC_SP(3,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.rDLPFC_SP(4,:)], 'r','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: lDLPFC/rDLPFC, SP')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_grand.lDLPFC_D2(3,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.rDLPFC_D2(4,:)], 'r','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: lDLPFC/rDLPFC, D2')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_grand.lDLPFC_D10(3,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_grand.rDLPFC_D10(4,:)], 'r','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: lDLPFC/rDLPFC, D10')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')

%% GRAND AVERAGE BUTTERFLY PLOTS

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_grand.mat'])
alldata_TEP_grand_lsp = alldata_TEP_grand.lDLPFC_SP; %input
alldata_TEP_grand_ld2 = alldata_TEP_grand.lDLPFC_D2; %input
alldata_TEP_grand_ld10 = alldata_TEP_grand.lDLPFC_D10; %input
alldata_TEP_grand_rsp = alldata_TEP_grand.rDLPFC_SP; %input
alldata_TEP_grand_rd2 = alldata_TEP_grand.rDLPFC_D2; %input
alldata_TEP_grand_rd10 = alldata_TEP_grand.rDLPFC_D10; %input

figure;
x = [-1500:1:1499];
t = tiledlayout(3,2);
t.TileSpacing = 'compact';

nexttile
for i=1:size(alldata_TEP_grand_lsp,1)
    plot(x,[alldata_TEP_grand_lsp(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_l = mean(alldata_TEP_grand_lsp([3,21,31,39],:),1);
plot(x,roi_l, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

nexttile
for i=1:size(alldata_TEP_grand_rsp,1)
    plot(x,[alldata_TEP_grand_rsp(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_r = mean(alldata_TEP_grand_rsp([4,22,32,40],:),1);
plot(x,roi_r, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

nexttile
for i=1:size(alldata_TEP_grand_ld2,1)
    plot(x,[alldata_TEP_grand_ld2(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_l = mean(alldata_TEP_grand_ld2([3,21,31,39],:),1);
plot(x,roi_l, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

nexttile
for i=1:size(alldata_TEP_grand_rd2,1)
    plot(x,[alldata_TEP_grand_rd2(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_r = mean(alldata_TEP_grand_rd2([4,22,32,40],:),1);
plot(x,roi_r, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

nexttile
for i=1:size(alldata_TEP_grand_ld10,1)
    plot(x,[alldata_TEP_grand_ld10(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_l = mean(alldata_TEP_grand_ld10([3,21,31,39],:),1);
plot(x,roi_l, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

nexttile
for i=1:size(alldata_TEP_grand_rd10,1)
    plot(x,[alldata_TEP_grand_rd10(i,:)], 'b', 'LineWidth', 1)
    hold on
end
roi_r = mean(alldata_TEP_grand_rd10([4,22,32,40],:),1);
plot(x,roi_r, 'r', 'LineWidth', 3.5) %input
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 14)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
%title('Grand average butterfly')
xlabel('Time (ms)', 'FontSize', 14, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 14, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 192);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 192);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 192);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 192);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 192);
line([0 0], [-10 -9.4], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

% pause(5)
% DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
% saveas(gcf,[DATAOUT, 'TEP_grand_butterfly.png']);


%%




%% Check all teps individual subjects

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])
xx = 7;

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_master(xx).lDLPFC_SP(3,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_master(xx).lDLPFC_D2(3,:)], 'r','LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_master(xx).lDLPFC_D10(3,:)], 'g','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 210], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')

figure;
x = [-1500:1:1499];
plot(x,[alldata_TEP_master(xx).rDLPFC_SP(4,:)], 'b', 'LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_master(xx).rDLPFC_D2(4,:)], 'r','LineWidth', 1.15)
hold on
plot(x,[alldata_TEP_master(xx).rDLPFC_D10(4,:)], 'g','LineWidth', 1.15)
xlim([-100 400])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
set(gca,'box','off')
title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
a.Color(4) = 0.2;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
b.Color(4) = 0.2;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
c.Color(4) = 0.2;
d = line([160 210], [0 0], 'Color', 'black', 'LineWidth', 255);
d.Color(4) = 0.2;
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')

% figure;
% x = [-1500:1:1499];
% plot(x,[alldata_TEP_master(xx).lDLPFC_SP(3,:)], 'b', 'LineWidth', 1.15)
% hold on
% plot(x,[alldata_TEP_master(xx).rDLPFC_SP(4,:)], 'r','LineWidth', 1.15)
% xlim([-100 400])
% ylim([-10 10])
% set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
% set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
% set(gca,'box','off')
% title('Grand average: lDLPFC/rDLPFC, SP')
% xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
% ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
% line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
% a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
% a.Color(4) = 0.2;
% b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
% b.Color(4) = 0.2;
% c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
% c.Color(4) = 0.2;
% d = line([160 210], [0 0], 'Color', 'black', 'LineWidth', 255);
% d.Color(4) = 0.2;
% legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')
% 
% figure;
% x = [-1500:1:1499];
% plot(x,[alldata_TEP_master(xx).lDLPFC_D2(3,:)], 'b', 'LineWidth', 1.15)
% hold on
% plot(x,[alldata_TEP_master(xx).rDLPFC_D2(4,:)], 'r','LineWidth', 1.15)
% xlim([-100 400])
% ylim([-10 10])
% set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
% set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
% set(gca,'box','off')
% title('Grand average: lDLPFC/rDLPFC, D2')
% xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
% ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
% line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
% a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
% a.Color(4) = 0.2;
% b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
% b.Color(4) = 0.2;
% c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
% c.Color(4) = 0.2;
% d = line([160 210], [0 0], 'Color', 'black', 'LineWidth', 255);
% d.Color(4) = 0.2;
% legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')
% 
% figure;
% x = [-1500:1:1499];
% plot(x,[alldata_TEP_master(xx).lDLPFC_D10(3,:)], 'b', 'LineWidth', 1.15)
% hold on
% plot(x,[alldata_TEP_master(xx).rDLPFC_D10(4,:)], 'r','LineWidth', 1.15)
% xlim([-100 400])
% ylim([-10 10])
% set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 10)
% set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
% set(gca,'box','off')
% title('Grand average: lDLPFC/rDLPFC, D10')
% xlabel('Time (ms)', 'FontSize', 10, 'FontWeight', 'bold')
% ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
% line([0 0], [-10 10], 'Color', 'black', 'LineStyle', '--')
% a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 255);
% a.Color(4) = 0.2;
% b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 255);
% b.Color(4) = 0.2;
% c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 255);
% c.Color(4) = 0.2;
% d = line([160 210], [0 0], 'Color', 'black', 'LineWidth', 255);
% d.Color(4) = 0.2;
% legend('lDLPFC', 'rDLPFC', 'FontSize', 10, 'FontWeight', 'bold')
 

%% TEP Grand average with ROI MASTERFILES 80%

%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_grand.mat'])
%load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master.mat'])

roi_l = [5];
%roi_l = [3,21,31,39];
%roi_r = [4,22,32,40];

alldata_TEP_master_roi_l_SP = zeros(1,3000);
alldata_TEP_master_roi_l_D2 = zeros(1,3000);
alldata_TEP_master_roi_l_D10 = zeros(1,3000);
alldata_TEP_master_roi_l_SP80 = zeros(1,3000);

% alldata_TEP_master_roi_r_SP = zeros(9,3000);
% alldata_TEP_master_roi_r_D2 = zeros(9,3000);
% alldata_TEP_master_roi_r_D10 = zeros(9,3000);
 
for i = 1:size(alldata_TEP_master,2)

    alldata_TEP_master_roi_l_SP(i,:) = mean(alldata_TEP_master(i).lDLPFC_SP(roi_l,:),1);
    alldata_TEP_master_roi_l_D2(i,:) = mean(alldata_TEP_master(i).lDLPFC_D2(roi_l,:),1);
    alldata_TEP_master_roi_l_D10(i,:) = mean(alldata_TEP_master(i).lDLPFC_D10(roi_l,:),1);
    alldata_TEP_master_roi_l_SP80(i,:) = mean(alldata_TEP_master(i).lDLPFC_SP80(roi_l,:),1);

%     alldata_TEP_master_roi_r_SP(i,:) = mean(alldata_TEP_master(i).rDLPFC_SP(roi_r,:),1);
%     alldata_TEP_master_roi_r_D2(i,:) = mean(alldata_TEP_master(i).rDLPFC_D2(roi_r,:),1);
%     alldata_TEP_master_roi_r_D10(i,:) = mean(alldata_TEP_master(i).rDLPFC_D10(roi_r,:),1);
end

% alldata_TEP_grand_roi_l_SP = mean(alldata_TEP_grand.lDLPFC_SP(roi_l,:),1);
% alldata_TEP_grand_roi_l_D2 = mean(alldata_TEP_grand.lDLPFC_D2(roi_l,:),1);
% alldata_TEP_grand_roi_l_D10 = mean(alldata_TEP_grand.lDLPFC_D10(roi_l,:),1);

% alldata_TEP_grand_roi_r_SP = mean(alldata_TEP_grand.rDLPFC_SP(roi_r,:),1);
% alldata_TEP_grand_roi_r_D2 = mean(alldata_TEP_grand.rDLPFC_D2(roi_r,:),1);
% alldata_TEP_grand_roi_r_D10 = mean(alldata_TEP_grand.rDLPFC_D10(roi_r,:),1);

% DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
% save([DATAOUT, 'alldata_TEP_master_roi_l_SP.mat'], 'alldata_TEP_master_roi_l_SP');
% save([DATAOUT, 'alldata_TEP_master_roi_l_D2.mat'], 'alldata_TEP_master_roi_l_D2');
% save([DATAOUT, 'alldata_TEP_master_roi_l_D10.mat'], 'alldata_TEP_master_roi_l_D10');
% save([DATAOUT, 'alldata_TEP_master_roi_r_SP.mat'], 'alldata_TEP_master_roi_r_SP');
% save([DATAOUT, 'alldata_TEP_master_roi_r_D2.mat'], 'alldata_TEP_master_roi_r_D2');
% save([DATAOUT, 'alldata_TEP_master_roi_r_D10.mat'], 'alldata_TEP_master_roi_r_D10');
% save([DATAOUT, 'alldata_TEP_grand_roi_l_SP.mat'], 'alldata_TEP_grand_roi_l_SP');
% save([DATAOUT, 'alldata_TEP_grand_roi_l_D2.mat'], 'alldata_TEP_grand_roi_l_D2');
% save([DATAOUT, 'alldata_TEP_grand_roi_l_D10.mat'], 'alldata_TEP_grand_roi_l_D10');
% save([DATAOUT, 'alldata_TEP_grand_roi_r_SP.mat'], 'alldata_TEP_grand_roi_r_SP');
% save([DATAOUT, 'alldata_TEP_grand_roi_r_D2.mat'], 'alldata_TEP_grand_roi_r_D2');
% save([DATAOUT, 'alldata_TEP_grand_roi_r_D10.mat'], 'alldata_TEP_grand_roi_r_D10');

%% 80%

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_master_roi_l_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_master_roi_l_D2, 'Color', [0.8500 0.3250 0.0980],'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_master_roi_l_D10, 'Color', [0.9290 0.6940 0.1250],'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_master_roi_l_SP80, 'Color', [0 0 0],'LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_l_D2, 0.12,[0.8500 0.3250 0.0980],x,[]);
stdshade(alldata_TEP_master_roi_l_D10, 0.12,[0.9290 0.6940 0.1250],x,[]);
stdshade(alldata_TEP_master_roi_l_SP80, 0.12,[0 0 0],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('spTMS', 'SICI', 'ICF', 'spTMS 80%', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

%%
figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_master_roi_l_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_master_roi_l_SP80, 'Color', [0 0 0],'LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_l_SP80, 0.12,[0 0 0],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('spTMS','spTMS 80%', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

%% subtraction method
test123 = alldata_TEP_master_roi_l_SP80;
test123(1:2) = [];
test123 = [test123 0 0 ];

test1234 = alldata_TEP_master_roi_l_SP80;
test1234(1:10) = [];
test1234 = [test1234 0 0 0 0 0 0 0 0 0 0 ];

newd2 = alldata_TEP_master_roi_l_D2-test123;
newd10 = alldata_TEP_master_roi_l_D10-test1234;

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_master_roi_l_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,newd2, 'Color', [0.8500 0.3250 0.0980],'LineWidth', 3.5)
hold on
plot(x,newd10, 'Color', [0.9290 0.6940 0.1250],'LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(newd2, 0.12,[0.8500 0.3250 0.0980],x,[]);
stdshade(newd10, 0.12,[0.9290 0.6940 0.1250],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('spTMS', 'SICI-cor', 'ICF-cor', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)

%% TEP grand average plots 

DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
load([DATAIN, 'alldata_TEP_master_roi_l_SP.mat']);
load([DATAIN, 'alldata_TEP_master_roi_l_D2.mat']);
load([DATAIN, 'alldata_TEP_master_roi_l_D10.mat']);
load([DATAIN, 'alldata_TEP_master_roi_r_SP.mat']);
load([DATAIN, 'alldata_TEP_master_roi_r_D2.mat']);
load([DATAIN, 'alldata_TEP_master_roi_r_D10.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_l_SP.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_l_D2.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_l_D10.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_r_SP.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_r_D2.mat']);
load([DATAIN, 'alldata_TEP_grand_roi_r_D10.mat']);

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_grand_roi_l_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_l_D2, 'Color', [0.8500 0.3250 0.0980],'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_l_D10, 'Color', [0.9290 0.6940 0.1250],'LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_l_D2, 0.12,[0.8500 0.3250 0.0980],x,[]);
stdshade(alldata_TEP_master_roi_l_D10, 0.12,[0.9290 0.6940 0.1250],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, lDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
f = line([(1676-1500) (1773-1500)], [-9 -9], 'Color', 'black', 'LineWidth', 4);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)
text((1725-1500-6), -8.7, '**', 'FontSize', 24)
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_grand_lDLPFC.png']);

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_grand_roi_r_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_r_D2, 'Color', [0.8500 0.3250 0.0980]','LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_r_D10, 'Color',[0.9290 0.6940 0.1250],'LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_r_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_r_D2, 0.12,[0.8500 0.3250 0.0980],x,[]);
stdshade(alldata_TEP_master_roi_r_D10, 0.12,[0.9290 0.6940 0.1250],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_grand_rDLPFC.png']);

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_grand_roi_l_SP, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_r_SP, 'Color', [0.8500 0.3250 0.0980]','LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_SP, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_r_SP, 0.12,[0.8500 0.3250 0.0980],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('lDLPFC', 'rDLPFC', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_grand_spTMS.png']);

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_grand_roi_l_D2, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_r_D2, 'Color', [0.8500 0.3250 0.0980]','LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_D2, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_r_D2, 0.12,[0.8500 0.3250 0.0980],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('lDLPFC', 'rDLPFC', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_grand_SICI.png']);

figure;
x = [-1500:1:1499];
plot(x,alldata_TEP_grand_roi_l_D10, 'Color', [0 0.4470 0.7410], 'LineWidth', 3.5)
hold on
plot(x,alldata_TEP_grand_roi_r_D10, 'Color', [0.8500 0.3250 0.0980]','LineWidth', 3.5)
stdshade(alldata_TEP_master_roi_l_D10, 0.12,[0 0.4470 0.7410],x,[]);
stdshade(alldata_TEP_master_roi_r_D10, 0.12,[0.8500 0.3250 0.0980],x,[]);
xlim([-100 500])
ylim([-10 10])
set(gca,'XTick',[-100,0,100,200,300,400], 'FontSize', 18)
set(gca,'xticklabel',({'-100', '0', '100', '200', '300', '400'}))
%title('Grand average: SP/SICI/ICF, rDLPFC')
xlabel('Time (ms)', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
a = line([55 75], [0 0], 'Color', 'black', 'LineWidth', 687);
a.Color(4) = 0.06;
b = line([30 50], [0 0], 'Color', 'black', 'LineWidth', 687);
b.Color(4) = 0.06;
c = line([90 140], [0 0], 'Color', 'black', 'LineWidth', 687);
c.Color(4) = 0.06;
d = line([160 240], [0 0], 'Color', 'black', 'LineWidth', 687);
d.Color(4) = 0.06;
e = line([-5 15], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 687);
line([0 0], [-10 -9.65], 'Color', 'black', 'LineStyle', '-', 'LineWidth', 2.5)
legend('lDLPFC', 'rDLPFC', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'LineWidth',2.5)
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_grand_ICF.png']);

%% STATISTICS: CLUSTER-BASED PERMUTATION TEST

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_l_SP.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_l_D2.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_l_D10.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_r_SP.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_r_D2.mat'])
load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_master_roi_r_D10.mat'])

x = transpose(alldata_TEP_master_roi_l_SP);
y = transpose(alldata_TEP_master_roi_l_D10);
d = true;
p = 0.05;
num_permutations = 512;
t = true;
num_clusters = [];

[clusters, p_values, t_sums, permutation_distribution ] = permutest(x, y, d, p, num_permutations, t, num_clusters);

%% Amplitude (and latency) files

ppns = {'TC910', 'TC913', 'TC915','TC916','TC918','TC919','TC920','TC921','TC922'};
brs = {'lDLPFC', 'rDLPFC'};
cons = {'SP', 'D2','D10'};

alldata_TEP_amp = struct('ppn', {}, 'lDLPFC_SP_N40', {},'lDLPFC_SP_P60', {},'lDLPFC_SP_N100', {},'lDLPFC_SP_P185',{} , 'lDLPFC_D2_N40', {},'lDLPFC_D2_P60', {},'lDLPFC_D2_N100', {},'lDLPFC_D2_P185',{}, 'lDLPFC_D10_N40', {},'lDLPFC_D10_P60', {},'lDLPFC_D10_N100', {},'lDLPFC_D10_P185',{}, 'rDLPFC_SP_N40', {},'rDLPFC_SP_P60', {},'rDLPFC_SP_N100', {},'rDLPFC_SP_P185',{} , 'rDLPFC_D2_N40', {},'rDLPFC_D2_P60', {},'rDLPFC_D2_N100', {},'rDLPFC_D2_P185',{}, 'rDLPFC_D10_N40', {},'rDLPFC_D10_P60', {},'rDLPFC_D10_N100', {},'rDLPFC_D10_P185',{});
alldata_TEP_lat = struct('ppn', {}, 'lDLPFC_SP_N40', {},'lDLPFC_SP_P60', {},'lDLPFC_SP_N100', {},'lDLPFC_SP_P185',{} , 'lDLPFC_D2_N40', {},'lDLPFC_D2_P60', {},'lDLPFC_D2_N100', {},'lDLPFC_D2_P185',{}, 'lDLPFC_D10_N40', {},'lDLPFC_D10_P60', {},'lDLPFC_D10_N100', {},'lDLPFC_D10_P185',{}, 'rDLPFC_SP_N40', {},'rDLPFC_SP_P60', {},'rDLPFC_SP_N100', {},'rDLPFC_SP_P185',{} , 'rDLPFC_D2_N40', {},'rDLPFC_D2_P60', {},'rDLPFC_D2_N100', {},'rDLPFC_D2_P185',{}, 'rDLPFC_D10_N40', {},'rDLPFC_D10_P60', {},'rDLPFC_D10_N100', {},'rDLPFC_D10_P185',{});

for ppn=1:size(ppns,2)
    alldata_TEP_amp(ppn).ppn = ppns{ppn};
    alldata_TEP_lat(ppn).ppn = ppns{ppn};
    for br=1:size(brs,2)
        for con=1:size(cons,2)
            DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/', ppns{ppn}, '/', brs{br}, '/'];
            EEG = pop_loadset('filename', [ppns{ppn}, '_preprocessed_', brs{br}, '_', cons{con},'.set'], 'filepath', [DATAIN]);

            if strcmpi(brs{br},'lDLPFC')
                EEG_l = pop_tesa_tepextract(EEG, 'ROI', 'elecs', {'F3', 'FC1', 'F1', 'FC3'}, 'tepName', 'lDLPFC' );
                EEG_l = pop_tesa_peakanalysis(EEG_l, 'ROI', 'positive', [60 185], [55 75;160 240], 'method', 'largest', 'samples', 5 );
                EEG_l = pop_tesa_peakanalysis(EEG_l, 'ROI', 'negative', [40 100], [30 50;90 140], 'method', 'largest', 'samples', 5 );
                peakoutput = pop_tesa_peakoutput(EEG_l, 'winType', 'individual', 'calcType', 'amplitude', 'tepName', 'lDLPFC', 'averageWin', 5, 'fixedPeak', [], 'tablePlot', 'off');   
            else
                EEG_r = pop_tesa_tepextract(EEG, 'ROI', 'elecs', {'F4', 'FC2', 'F2', 'FC4'}, 'tepName', 'rDLPFC' );
                EEG_r = pop_tesa_peakanalysis(EEG_r, 'ROI', 'positive', [60 185], [55 75;160 240], 'method', 'largest', 'samples', 5 );
                EEG_r = pop_tesa_peakanalysis( EEG_r, 'ROI', 'negative', [40 100], [30 50;90 140], 'method', 'largest', 'samples', 5 );
                peakoutput = pop_tesa_peakoutput(EEG_r, 'winType', 'individual', 'calcType', 'amplitude', 'tepName', 'rDLPFC', 'averageWin', 5, 'fixedPeak', [], 'tablePlot', 'off');   
            end
            
            if strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TEP_amp(ppn).lDLPFC_SP_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).lDLPFC_SP_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).lDLPFC_SP_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).lDLPFC_SP_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).lDLPFC_SP_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).lDLPFC_SP_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).lDLPFC_SP_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).lDLPFC_SP_P185 = peakoutput(4).lat;                              
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TEP_amp(ppn).lDLPFC_D2_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).lDLPFC_D2_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).lDLPFC_D2_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).lDLPFC_D2_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).lDLPFC_D2_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).lDLPFC_D2_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).lDLPFC_D2_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).lDLPFC_D2_P185 = peakoutput(4).lat;
            elseif strcmpi(brs{br}, 'lDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TEP_amp(ppn).lDLPFC_D10_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).lDLPFC_D10_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).lDLPFC_D10_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).lDLPFC_D10_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).lDLPFC_D10_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).lDLPFC_D10_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).lDLPFC_D10_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).lDLPFC_D10_P185 = peakoutput(4).lat;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'SP')
                alldata_TEP_amp(ppn).rDLPFC_SP_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).rDLPFC_SP_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).rDLPFC_SP_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).rDLPFC_SP_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).rDLPFC_SP_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).rDLPFC_SP_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).rDLPFC_SP_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).rDLPFC_SP_P185 = peakoutput(4).lat;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D2')
                alldata_TEP_amp(ppn).rDLPFC_D2_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).rDLPFC_D2_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).rDLPFC_D2_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).rDLPFC_D2_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).rDLPFC_D2_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).rDLPFC_D2_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).rDLPFC_D2_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).rDLPFC_D2_P185 = peakoutput(4).lat;
            elseif strcmpi(brs{br}, 'rDLPFC') && strcmpi(cons{con}, 'D10')
                alldata_TEP_amp(ppn).rDLPFC_D10_N40 = peakoutput(1).amp;
                alldata_TEP_amp(ppn).rDLPFC_D10_P60 = peakoutput(2).amp;
                alldata_TEP_amp(ppn).rDLPFC_D10_N100 = peakoutput(3).amp;
                alldata_TEP_amp(ppn).rDLPFC_D10_P185 = peakoutput(4).amp;
                
                alldata_TEP_lat(ppn).rDLPFC_D10_N40 = peakoutput(1).lat;
                alldata_TEP_lat(ppn).rDLPFC_D10_P60 = peakoutput(2).lat;
                alldata_TEP_lat(ppn).rDLPFC_D10_N100 = peakoutput(3).lat;
                alldata_TEP_lat(ppn).rDLPFC_D10_P185 = peakoutput(4).lat;
            end
           
        end
    end
end

DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%save([DATAOUT, 'alldata_TEP_lat.mat'], 'alldata_TEP_lat');
%save([DATAOUT, 'alldata_TEP_amp.mat'], 'alldata_TEP_amp');

alldata_TEP_amp_new = rmfield(alldata_TEP_amp, 'ppn');
alldata_amp_wide = struct2table(alldata_TEP_amp_new);
%writetable(alldata_amp_wide, ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_amp_wide.xlsx'])

%% Amplitude graphs

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_amp.mat'])

alldata_TEP_amp_new = rmfield(alldata_TEP_amp, 'ppn');
alldata_amp_mat = transpose(squeeze(cell2mat(struct2cell(alldata_TEP_amp_new))));
alldata_amp_l = alldata_amp_mat(:,1:12);
alldata_amp_r = alldata_amp_mat(:,13:end);

X = categorical({'N40','P60','N100','P185'});
X = reordercats(X,{'N40','P60','N100','P185'});
y_l = reshape(mean(alldata_amp_l),[4,3]);
y_r = reshape(mean(alldata_amp_r),[4,3]);
%err_l = reshape(std(alldata_amp_l), [4,3]);
%err_r = reshape(std(alldata_amp_r), [4,3]);
err_l = reshape(std(alldata_amp_l)/sqrt(size(alldata_amp_l,1)),[4,3]);
err_r = reshape(std(alldata_amp_r)/sqrt(size(alldata_amp_r,1)), [4,3]);

figure
b_l = bar(X,y_l, 'grouped', 'EdgeColor',[0 0 0],'LineWidth',2.5);
hold on
[ngroups,nbars] = size(y_l);
x_bars = nan(nbars, ngroups);
for i = 1:nbars
    x_bars(i,:) = b_l(i).XEndPoints;
end
errorbar(x_bars',y_l,err_l,'k','linestyle','none', 'LineWidth',2.5);
hold off
b_l(1).FaceColor = [0 0.4470 0.7410];
b_l(2).FaceColor = [0.8500 0.3250 0.0980];
b_l(3).FaceColor = [0.9290 0.6940 0.1250];
ylim([-7 10])
%title('Peak Amplitudes lDLPFC')
line([x_bars(1,1) x_bars(2,1)], [-3.5 -3.5], 'Color', 'black', 'LineWidth', 2.5);
line([x_bars(1,1) x_bars(1,1)], [(y_l(1,1)-err_l(1,1)-0.5) -3.51], 'Color', 'black', 'LineWidth', 2.5);
line([x_bars(2,1) x_bars(2,1)], [(y_l(1,2)-err_l(1,2)-0.5) -3.51], 'Color', 'black', 'LineWidth', 2.5);
text(x_bars(1,1)+((x_bars(2,1)-x_bars(1,1))/2)-0.03, -3.8, '*', 'FontSize', 24)
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
axis square
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
xlabel('TEP component', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_amp_lDLPFC.png']);

figure
b_r = bar(X,y_r, 'grouped', 'EdgeColor',[0 0 0],'LineWidth',2.5);
hold on
errorbar(x_bars',y_r,err_r,'k','linestyle','none', 'LineWidth',2.5);
hold off
b_r(1).FaceColor = [0 0.4470 0.7410];
b_r(2).FaceColor = [0.8500 0.3250 0.0980];
b_r(3).FaceColor = [0.9290 0.6940 0.1250];
ylim([-7 10])
%title('Peak Amplitudes rDLPFC')
legend('spTMS', 'SICI', 'ICF', 'FontSize', 22, 'FontWeight', 'bold')
legend boxoff
axis square
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'box','off')
set(gca, 'FontSize', 18)
set(gca, 'LineWidth',2.5)
xlabel('TEP component', 'FontSize', 22, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 22, 'FontWeight', 'bold')
%pause(5)
%DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/'];
%saveas(gcf,[DATAOUT, 'TEP_amp_rDLPFC.png']);


%% Latency averages

load(['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/results/TEP/alldata_TEP_lat.mat'])

lat_N40 = alldata_lat_mat(:,[1,5,9,13,17,21]);
lat_P60 = alldata_lat_mat(:,[2,6,10,14,18,22]);
lat_N100 =alldata_lat_mat(:,[3,7,11,15,19,23]);
lat_P185 =alldata_lat_mat(:,[4,8,12,16,20,24]);
lat_N40_nan = ((numel(lat_N40)-length(find(isnan(lat_N40))))/ numel(lat_N40))*100;
lat_P60_nan = ((numel(lat_P60)-length(find(isnan(lat_P60))))/ numel(lat_P60))*100;
lat_N100_nan = ((numel(lat_N100)-length(find(isnan(lat_N100))))/ numel(lat_N100))*100;
lat_P185_nan = ((numel(lat_P185)-length(find(isnan(lat_P185))))/ numel(lat_P185))*100;

alldata_TEP_lat_new = rmfield(alldata_TEP_lat, 'ppn');
alldata_lat_mat = transpose(squeeze(cell2mat(struct2cell(alldata_TEP_lat_new))));
alldata_lat_l = alldata_lat_mat(:,1:12);
alldata_lat_r = alldata_lat_mat(:,13:end);
y_l = reshape(nanmean(alldata_lat_l),[4,3]);
y_r = reshape(nanmean(alldata_lat_r),[4,3]);
err_l = reshape(nanstd(alldata_lat_l), [4,3]);
err_r = reshape(nanstd(alldata_lat_r), [4,3]);

%% Statistics

%[a,b] = vartest2(alldata_amp_r(:,4),alldata_amp_r(:,8))

l1 = alldata_amp_l(:,[1,5,9]);
l2 = alldata_amp_l(:,[2,6,10]);
l3 = alldata_amp_l(:,[3,7,11]);
l4 = alldata_amp_l(:,[4,8,12]);
r1 = alldata_amp_r(:,[1,5,9]);
r2 = alldata_amp_r(:,[2,6,10]);
r3 = alldata_amp_r(:,[3,7,11]);
r4 = alldata_amp_r(:,[4,8,12]);

[a,b,stats ]= friedman(r4)
[t] = multcompare(stats)

[a,b] = jbtest(alldata_amp_l(:,1))
[a,b] = jbtest(alldata_amp_l(:,2))
[a,b] = jbtest(alldata_amp_l(:,3))
[a,b] = jbtest(alldata_amp_l(:,4))
[a,b] = jbtest(alldata_amp_l(:,5))
[a,b] = jbtest(alldata_amp_l(:,6))
[a,b] = jbtest(alldata_amp_l(:,7))
[a,b] = jbtest(alldata_amp_l(:,8))
[a,b] = jbtest(alldata_amp_l(:,9))
[a,b] = jbtest(alldata_amp_l(:,10))
[a,b] = jbtest(alldata_amp_l(:,11))
[a,b] = jbtest(alldata_amp_l(:,12))

[a,b] = jbtest(alldata_amp_r(:,1))
[a,b] = jbtest(alldata_amp_r(:,2))
[a,b] = jbtest(alldata_amp_r(:,3))
[a,b] = jbtest(alldata_amp_r(:,4))
[a,b] = jbtest(alldata_amp_r(:,5))
[a,b] = jbtest(alldata_amp_r(:,6))
[a,b] = jbtest(alldata_amp_r(:,7))
[a,b] = jbtest(alldata_amp_r(:,8))
[a,b] = jbtest(alldata_amp_r(:,9))
[a,b] = jbtest(alldata_amp_r(:,10))
[a,b] = jbtest(alldata_amp_r(:,11))
[a,b] = jbtest(alldata_amp_r(:,12))

[a,b] = vartest2(alldata_amp_l(:,1),alldata_amp_l(:,5))
[a,b] = vartest2(alldata_amp_l(:,1),alldata_amp_l(:,9))
[a,b] = vartest2(alldata_amp_l(:,2),alldata_amp_l(:,6))
[a,b] = vartest2(alldata_amp_l(:,2),alldata_amp_l(:,10))
[a,b] = vartest2(alldata_amp_l(:,3),alldata_amp_l(:,7))
[a,b] = vartest2(alldata_amp_l(:,3),alldata_amp_l(:,11))
[a,b] = vartest2(alldata_amp_l(:,4),alldata_amp_l(:,8))
[a,b] = vartest2(alldata_amp_l(:,4),alldata_amp_l(:,12))

[a,b] = vartest2(alldata_amp_r(:,1),alldata_amp_r(:,5))
[a,b] = vartest2(alldata_amp_r(:,1),alldata_amp_r(:,9))
[a,b] = vartest2(alldata_amp_r(:,2),alldata_amp_r(:,6))
[a,b] = vartest2(alldata_amp_r(:,2),alldata_amp_r(:,10))
[a,b] = vartest2(alldata_amp_r(:,3),alldata_amp_r(:,7))
[a,b] = vartest2(alldata_amp_r(:,3),alldata_amp_r(:,11))
[a,b] = vartest2(alldata_amp_r(:,4),alldata_amp_r(:,8))
[a,b] = vartest2(alldata_amp_r(:,4),alldata_amp_r(:,12))

[tl40sici,pl40sici] = ttest(alldata_amp_l(:,1),alldata_amp_l(:,5))
[tl40icf, pl40icf] = ttest(alldata_amp_l(:,1),alldata_amp_l(:,9))
[tl60sici,pl60sici] = ttest(alldata_amp_l(:,2),alldata_amp_l(:,6))
[tl60icf, pl60icf] = ttest(alldata_amp_l(:,2),alldata_amp_l(:,10))
[tl100sici,pl100sici] = ttest(alldata_amp_l(:,3),alldata_amp_l(:,7))
[tl100icf, pl100icf] = ttest(alldata_amp_l(:,3),alldata_amp_l(:,11))
[tl185sici,pl185sici] = ttest(alldata_amp_l(:,4),alldata_amp_l(:,8))
[tl185icf, pl185icf] = ttest(alldata_amp_l(:,4),alldata_amp_l(:,12))

[tr40sici,pr40sici] = ttest(alldata_amp_r(:,1),alldata_amp_r(:,5))
[tr40icf, pr40icf] = ttest(alldata_amp_r(:,1),alldata_amp_r(:,9))
[tr60sici,pr60sici] = ttest(alldata_amp_r(:,2),alldata_amp_r(:,6))
[tr60icf, pr60icf] = ttest(alldata_amp_r(:,2),alldata_amp_r(:,10))
[tr100sici,pr100sici] = ttest(alldata_amp_r(:,3),alldata_amp_r(:,7))
[tr100icf, pr100icf] = ttest(alldata_amp_r(:,3),alldata_amp_r(:,11))
[tr185sici,pr185sici] = ttest(alldata_amp_r(:,4),alldata_amp_r(:,8))
[tr185icf, pr185icf] = ttest(alldata_amp_r(:,4),alldata_amp_r(:,12))

[t40sp,p40sp] = ttest(alldata_amp_l(:,1),alldata_amp_r(:,1))
[t40sici,p40sici] = ttest(alldata_amp_l(:,2),alldata_amp_r(:,2))
[t40icf, p40icf] = ttest(alldata_amp_l(:,3),alldata_amp_r(:,3))
[t60sp,p60sp] = ttest(alldata_amp_l(:,4),alldata_amp_r(:,4))
[t60sici,p60sici] = ttest(alldata_amp_l(:,5),alldata_amp_r(:,5))
[t60icf, p60icf] = ttest(alldata_amp_l(:,6),alldata_amp_r(:,6))
[t100sp,p100sp] = ttest(alldata_amp_l(:,7),alldata_amp_r(:,7))
[t100sici,p100sici] = ttest(alldata_amp_l(:,8),alldata_amp_r(:,8))
[t100icf, p100icf] = ttest(alldata_amp_l(:,9),alldata_amp_r(:,9))
[t185sp, p185sp] = ttest(alldata_amp_l(:,10),alldata_amp_r(:,10))
[t185sici,p185sici] = ttest(alldata_amp_l(:,11),alldata_amp_r(:,11))
[t185icf, p185icf] = ttest(alldata_amp_l(:,12),alldata_amp_r(:,12))

%% Peak-to-peak analysis

y_ll(:,1) = abs(alldata_amp_l(:,2)-alldata_amp_l(:,1));
y_ll(:,2) = abs(alldata_amp_l(:,3)-alldata_amp_l(:,2));
y_ll(:,3) = abs(alldata_amp_l(:,4)-alldata_amp_l(:,3));
y_ll(:,4) = abs(alldata_amp_l(:,6)-alldata_amp_l(:,5));
y_ll(:,5) = abs(alldata_amp_l(:,7)-alldata_amp_l(:,6));
y_ll(:,6) = abs(alldata_amp_l(:,8)-alldata_amp_l(:,7));
y_ll(:,7) = abs(alldata_amp_l(:,10)-alldata_amp_l(:,9));
y_ll(:,8) = abs(alldata_amp_l(:,11)-alldata_amp_l(:,10));
y_ll(:,9) = abs(alldata_amp_l(:,12)-alldata_amp_l(:,11));

y_rr(:,1) = abs(alldata_amp_l(:,2)-alldata_amp_l(:,1));
y_rr(:,2) = abs(alldata_amp_l(:,3)-alldata_amp_l(:,2));
y_rr(:,3) = abs(alldata_amp_l(:,4)-alldata_amp_l(:,3));
y_rr(:,4) = abs(alldata_amp_l(:,6)-alldata_amp_l(:,5));
y_rr(:,5) = abs(alldata_amp_l(:,7)-alldata_amp_l(:,6));
y_rr(:,6) = abs(alldata_amp_l(:,8)-alldata_amp_l(:,7));
y_rr(:,7) = abs(alldata_amp_l(:,10)-alldata_amp_l(:,9));
y_rr(:,8) = abs(alldata_amp_l(:,11)-alldata_amp_l(:,10));
y_rr(:,9) = abs(alldata_amp_l(:,12)-alldata_amp_l(:,11));


X = categorical({'P60-N40','N100-P60','P185-N100'});
X = reordercats(X,{'P60-N40','N100-P60','P185-N100'});
y_l = reshape(mean(y_ll),[3,3]);
y_r = reshape(mean(y_rr),[3,3]);
%err_l = reshape(std(alldata_amp_l), [4,3]);
%err_r = reshape(std(alldata_amp_r), [4,3]);
err_l = reshape(std(y_ll)/sqrt(size(y_ll,1)),[3,3]);
err_r = reshape(std(y_rr)/sqrt(size(y_rr,1)), [3,3]);

figure
b_l = bar(X,y_l, 'grouped');
hold on
[ngroups,nbars] = size(y_l);
x_bars = nan(nbars, ngroups);
for i = 1:nbars
    x_bars(i,:) = b_l(i).XEndPoints;
end
errorbar(x_bars',y_l,err_l,'k','linestyle','none');
hold off
b_l(1).FaceColor = [0 0.4470 0.7410];
b_l(2).FaceColor = [0.8500 0.3250 0.0980];
b_l(3).FaceColor = [0.9290 0.6940 0.1250];
%ylim([-7 10])
title('Peak-to-Peak Amplitudes lDLPFC')
xlabel('TEP components', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')
axis square

figure
b_r = bar(X,y_r, 'grouped');
hold on
errorbar(x_bars',y_r,err_r,'k','linestyle','none');
hold off
b_r(1).FaceColor = [0 0.4470 0.7410];
b_r(2).FaceColor = [0.8500 0.3250 0.0980];
b_r(3).FaceColor = [0.9290 0.6940 0.1250];
%ylim([-7 10])
title('Peak-to-Peak Amplitudes rDLPFC')
xlabel('TEP component', 'FontSize', 10, 'FontWeight', 'bold')
ylabel(['Amplitude (', char(181),'V)'], 'FontSize', 10, 'FontWeight', 'bold')
legend('SP', 'SICI', 'ICF', 'FontSize', 10, 'FontWeight', 'bold')
axis square


