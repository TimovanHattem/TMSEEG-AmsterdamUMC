% PREPROCESSING SINGLE-PULSE TMS-EEG DATA
%
% Timo van Hattem
% Updated: 13-3-2023

cd('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/pilot_80%/')
%% Clean workspace
clear
close all
clc

%% Set path
%addpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/');
%addpath(genpath('/data/anw/anw-gold/NP/projects/data_TIPICCO/TMS_EEG/tvh/eeglab2023.0/FastICA_25/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/'));
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_scripts/')); 
addpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0')
addpath(genpath('/scratch/anw/tvanhattem/analysis_tvh/eeglab2023.0/FastICA_25/')); 
fprintf('Paths added!\n')

%% Initialize variables
ppn = 'pilot_80%'; %input subject number
br = 'M1'; %input brain region of interest
con = 'D10'; %input condition

%set input and output paths
DATAIN = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/raw_epochs/', ppn, '/', br, '/'];
DATAOUT = ['/scratch/anw/tvanhattem/analysis_tvh/TMSEEG_data/preprocessed/clean_epochs/'];

%% Import data
eeglab;
EEG = pop_loadset('filename', [ppn, '_rawepochs_', br, '_', con, '.set'], 'filepath', [DATAIN]);

%% Remove TMS artefact 
if strcmpi(con, 'SP') || strcmpi(con, 'SP80')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]);
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]);
end

%% Interpolate 
EEG = pop_tesa_interpdata(EEG, 'cubic', [1 1]);

%% Downsample
EEG = pop_resample(EEG, 1000);

%% Automated removal bad epochs
EEG = pop_jointprob(EEG,1,[1:size(EEG,1)],3,3,0,1,0,[],0);
EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent]));

%% Manual check data

% trial rejection
pop_eegplot(EEG,1,1,1)
EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent]));

% bad channel rejection
%EEG = pop_select(EEG, 'nochannel', {'P3','P4','O1','O2','T7','T8','P7','P8','PZ','IZ','TP9','P1','P2','PO4','P5','P6','TP7','TP8','PO7','PO8','POZ','OZ'}); %manual input
%EEG.rejchan = find(~ismember([EEG.allchan.urchan], [EEG.chanlocs.urchan]));

%% Remove data
if strcmpi(con, 'SP') || strcmpi(con, 'SP80')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]);
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]);
end

%% ICA round 1
EEG = pop_tesa_fastica(EEG, 'approach', 'symm', 'g', 'tanh', 'stabilization', 'on');
EEG = pop_tesa_compselect(EEG,'compCheck','on','remove','on','saveWeights','off', 'figSize','medium','plotTimeX',[-200 500],'plotFreqX',[1 100],'freqScale', 'log', 'tmsMuscle','on','tmsMuscleThresh',8,'tmsMuscleWin',[15 30],'tmsMuscleFeedback','off','blink','off','blinkThresh',2.5,'blinkElecs',{'Fp1','Fp2'},'blinkFeedback','off','move','off','moveThresh',2,'moveElecs',{'F7','F8'},'moveFeedback','off','muscle','off','muscleThresh',-0.31,'muscleFreqIn',[7 70],'muscleFreqEx',[48 52],'muscleFeedback','off','elecNoise','off','elecNoiseThresh',4,'elecNoiseFeedback','off' );

%% Interpolate 
EEG = pop_tesa_interpdata(EEG, 'cubic', [10 10]);

%% Filtering
EEG = pop_tesa_filtbutter(EEG, 1, 80, 4, 'bandpass');
EEG = pop_tesa_filtbutter(EEG, 48, 52, 4, 'bandstop' );
%EEG_erp = pop_tesa_filtbutter(EEG, 1, 45, 4, 'bandpass');

%% SOUND
%EEG = pop_tesa_sound(EEG, 'lambdaValue', 0.1, 'iter', 5);

%% Manual trial rejection 
pop_eegplot(EEG,1,1,1)
%EEG = pop_select(EEG, 'notrial', [25]); %manual input
%EEG.rejepoch = find(~ismember([EEG.rawepochs.eventurevent], [EEG.epoch.eventurevent]));

%% Remove data around TMS-puls and add constant amplitude
if strcmpi(con, 'SP') || strcmpi(con, 'SP80')
    EEG = pop_tesa_removedata(EEG, [-5 15]);
elseif strcmpi(con, 'D2')
    EEG = pop_tesa_removedata(EEG, [-7 15]);
elseif strcmpi(con, 'D10')
    EEG = pop_tesa_removedata(EEG, [-15 15]);
end

%% ICA round 2
EEG = pop_tesa_fastica(EEG, 'approach', 'symm', 'g', 'tanh', 'stabilization', 'on');
EEG = pop_tesa_compselect(EEG,'compCheck','on','remove','on','saveWeights','off', 'figSize','medium','plotTimeX',[-200 500],'plotFreqX',[1 100],'freqScale', 'log', 'tmsMuscle','on','tmsMuscleThresh',8,'tmsMuscleWin',[15 30],'tmsMuscleFeedback','off','blink','on','blinkThresh',2.5,'blinkElecs',{'AF7','AF8'},'blinkFeedback','off','move','on','moveThresh',2,'moveElecs',{'F7','F8'},'moveFeedback','off','muscle','on','muscleThresh',-0.31,'muscleFreqIn',[7 70],'muscleFreqEx',[48 52],'muscleFeedback','off','elecNoise','on','elecNoiseThresh',4,'elecNoiseFeedback','off' );

%% Interpolate data around TMS-pulse
EEG = pop_tesa_interpdata(EEG, 'cubic', [10 10]);

%% Interpolate removed channels
EEG = pop_interp(EEG, EEG.allchan, 'spherical');

%% Rereference data to average of all electrodes
EEG = pop_reref(EEG, []);
%pop_eegplot(EEG,1,1,1)

%% Save dataset
mkdir([DATAOUT, '/', ppn, '/', br])
pop_saveset(EEG, 'filename', [ppn, '_preprocessed_', br, '_', con, '.set'], 'filepath', [DATAOUT, '/', ppn, '/' br]);

