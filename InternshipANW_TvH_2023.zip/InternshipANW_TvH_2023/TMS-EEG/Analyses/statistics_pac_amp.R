library(readxl)
library(car)
library(tidyverse)
library(ggpubr)
library(rstatix)

################################################################################
# TEP One-way Repeated Measures ANOVA + Post-hoc

data = read_xlsx(file.choose())

ppns = 1:9
data = cbind(ppns, data)
data$ppns = as.factor(data$ppns)	#input

data_l_n40 = data[, c(1,2,6,10)]
data_l_p60 = data[, c(1,3,7,11)]
data_l_n100 = data[, c(1,4,8,12)]
data_l_p185 = data[, c(1,5,9,13)]
data_r_n40 = data[, c(1,14,18,22)]
data_r_p60 = data[, c(1,15,19,23)]
data_r_n100 = data[, c(1,16,20,24)]
data_r_p185 = data[, c(1,17,21,25)]

cur_data_wide = data_r_p185

colnames(cur_data_wide) <- c("ppns", "SP", "D2", "D10") 

fit.lm = lm(cbind(cur_data_wide$SP, cur_data_wide$D2, cur_data_wide$D10) ~ 1, data = cur_data_wide)
mauchly.test(fit.lm, X = ~ 1)	
shapiro.test(fit.lm$residuals)	

anova(fit.lm, X = ~ 1, test = "Spherical")	

cur_data_long = reshape(cur_data_wide, varying = c("SP", "D2", "D10"), v.names = "amp", timevar = "con", times = cbind("SP", "D2", "D10"), idvar = "ppns", direction = "long")
pairwise.t.test(cur_data_long$amp, cur_data_long$con, paired = TRUE, p.adjust.method = "bonferroni", alternative = c("two.sided"))

################################################################################

# TEP Two-way Repeated Measures ANOVA + Post-hoc

data = read_xlsx(file.choose()) # load data in long format
data$ppns = as.factor(data$ppns)
data$br = as.factor(data$br)
data$con = as.factor(data$con)

data %>% group_by(br, con) %>% get_summary_stats(amp_p185, type = "mean_sd")

bxp <- ggboxplot(data, x = "con", y = "amp_p185",
                 color = "br", palette = "jco")
bxp

data %>% group_by(br, con) %>% identify_outliers(amp_p185)

data %>% group_by(br, con) %>% shapiro_test(amp_p185)

ggqqplot(data, "amp_p185", ggtheme = theme_bw()) +
  facet_grid(con ~ br, labeller = "label_both")

res.aov <- anova_test(data = data, dv = amp_p185, wid = ppns, within = c(br, con))
get_anova_table(res.aov)

data %>% pairwise_t_test(amp_p185 ~ br, paired = TRUE,p.adjust.method = "bonferroni")
data %>% pairwise_t_test(amp_p185 ~ con, paired = TRUE, p.adjust.method = "bonferroni")

pwc <- data %>% group_by(con) %>% pairwise_t_test(amp_p185 ~ br, paired = TRUE,
                                                  p.adjust.method = "bonferroni")
pwc
pwc2 <- data %>% group_by(br) %>% pairwise_t_test(amp_p185 ~ con, paired = TRUE,
                                                  p.adjust.method = "bonferroni")
pwc2

#################################################################################

# PAC One-way Repeated Measures ANOVA + Post-hoc

data = read_xlsx(file.choose()) # load data in wide format

ppns = 1:9
data = cbind(ppns, data)
data$ppns = as.factor(data$ppns)	#input

data_l = data[, c(1,2,3,4)]
data_r = data[, c(1,5,6,7)]
colnames(data_l) <- c("ppns", "SP", "D2", "D10") 
colnames(data_r) <- c("ppns", "SP", "D2", "D10") 

fit.lm = lm(cbind(data_r$SP, data_r$D2, data_r$D10) ~ 1, data = data_r)
mauchly.test(fit.lm, X = ~ 1)	
shapiro.test(fit.lm$residuals)	

anova(fit.lm, X = ~ 1, test = "Spherical")	

data_long = reshape(data_r, varying = c("SP", "D2", "D10"), v.names = "pac", timevar = "con", times = cbind("SP", "D2", "D10"), idvar = "ppns", direction = "long")
pairwise.t.test(data_long$pac, data_long$con, paired = TRUE, p.adjust.method = "bonferroni", alternative = c("two.sided"))

t.test(data$MI_lDLPFC_SP, data$MI_rDLPFC_SP, alternative = c("two.sided"), mu = 0, paired = T, var.equal = T, conf.level = 0.95)
t.test(data$MI_lDLPFC_D2, data$MI_rDLPFC_D2, alternative = c("two.sided"), mu = 0, paired = T, var.equal = T, conf.level = 0.95)
t.test(data$MI_lDLPFC_D10, data$MI_rDLPFC_D10, alternative = c("two.sided"), mu = 0, paired = T, var.equal = T, conf.level = 0.95)

##################################################################################

# PAC Two-way Repeated Measures ANOVA + Post-hoc

data = read_xlsx(file.choose()) # load data in long format
data$ppns = as.factor(data$ppns)
data$br = as.factor(data$br)
data$con = as.factor(data$con)

data %>% group_by(br, con) %>% get_summary_stats(pac, type = "mean_sd")

bxp <- ggboxplot(data, x = "con", y = "pac",
  color = "br", palette = "jco")
bxp

data %>% group_by(br, con) %>% identify_outliers(pac)

data %>% group_by(br, con) %>% shapiro_test(pac)

ggqqplot(data, "pac", ggtheme = theme_bw()) +
  facet_grid(con ~ br, labeller = "label_both")

res.aov <- anova_test(data = data, dv = pac, wid = ppns, within = c(br, con))
get_anova_table(res.aov)

data %>% pairwise_t_test(pac ~ br, paired = TRUE,p.adjust.method = "bonferroni")
data %>% pairwise_t_test(pac ~ con, paired = TRUE, p.adjust.method = "bonferroni")

pwc <- data %>% group_by(con) %>% pairwise_t_test(pac ~ br, paired = TRUE,
    p.adjust.method = "bonferroni")
pwc
pwc2 <- data %>% group_by(br) %>% pairwise_t_test(pac ~ con, paired = TRUE,
    p.adjust.method = "bonferroni")
pwc2
